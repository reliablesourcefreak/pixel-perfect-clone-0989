# AI Art Database → Personal Creative OS: UX/UI Assessment & Redesign Proposal

## Current State Assessment

### What Works Well
- **Swiss typography foundation** is clean and professional, good baseline
- **Red/black/white palette** is bold and memorable
- **Drag-and-drop upload** is intuitive
- **AI auto-categorization** removes friction
- **Filter sidebar** is logical for browsing

### Critical Issues for Personal Use
1. **Gallery-first mindset** — Designed for viewers, not creators. Missing workspace context.
2. **No narrative structure** — Art exists in isolation; no way to group pieces into stories, projects, or themes.
3. **Shallow metadata** — Tags and categories alone don't capture creative intent, evolution, or connections.
4. **No knowledge base** — Can't document ideas, character bibles, world-building, or creative decisions.
5. **No timeline** — Can't see creative evolution or chronological progression.
6. **No export/deployment** — Can't repurpose work for other platforms without manual extraction.
7. **Flat information hierarchy** — Everything is equal; no distinction between reference, draft, final, or published work.
8. **No collaboration with self** — Can't link ideas across projects or see patterns in your own work.

---

## Proposed Architecture: "Orbit" (Personal Creative OS)

### Core Concept
**Orbit** is your **visual GitHub** — a workspace where every artwork is a commit, every collection is a branch, every story is a release. It's modular, interconnected, and designed for **you to organize, evolve, and deploy your creative work**.

### Information Model

```
Workspace (You)
├── Collections (Projects/Series)
│   ├── Artworks (Individual pieces)
│   ├── Codex Pages (World-building, characters, lore)
│   ├── Timeline (Chronological view)
│   └── Story Compilation (Narrative threads)
├── Codex (Global knowledge base)
│   ├── Characters
│   ├── Worlds/Settings
│   ├── Concepts/Themes
│   ├── Techniques/Processes
│   └── References
├── Mindmap (Visual relationship graph)
│   ├── Art-to-art connections
│   ├── Art-to-codex links
│   └── Story threads
└── Exports (Deployable packages)
    ├── Web galleries
    ├── Social media collections
    ├── PDF portfolios
    └── Interactive timelines
```

---

## UX/UI Redesign Proposal

### 1. Navigation Model: Workspace Hub (Left Sidebar)

**Replace top nav with persistent left sidebar (collapsible on mobile):**

```
┌─────────────────────────────────────────────────────────────┐
│ ORBIT                                                    [☰] │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│ 📊 DASHBOARD                                                 │
│    • Quick stats (total artworks, collections, stories)      │
│    • Recent uploads                                          │
│    • Pinned collections                                      │
│                                                               │
│ 🎨 COLLECTIONS                                               │
│    ├─ Character Studies (12 pieces)                          │
│    ├─ Sci-Fi World (28 pieces)                               │
│    ├─ Experimental (5 pieces)                                │
│    └─ [+ New Collection]                                     │
│                                                               │
│ 📖 CODEX                                                      │
│    ├─ Characters (8)                                         │
│    ├─ Worlds (3)                                             │
│    ├─ Concepts (12)                                          │
│    └─ [+ New Entry]                                          │
│                                                               │
│ 📚 STORIES                                                    │
│    ├─ "The Exodus" (story + 15 artworks)                     │
│    ├─ "Origin" (story + 8 artworks)                          │
│    └─ [+ New Story]                                          │
│                                                               │
│ 🗺️ MINDMAP                                                    │
│    • Visual graph of all connections                         │
│                                                               │
│ ⏱️ TIMELINE                                                   │
│    • Chronological view of all work                          │
│                                                               │
│ 📤 EXPORTS                                                    │
│    ├─ Web Galleries                                          │
│    ├─ Portfolios                                             │
│    └─ Social Collections                                     │
│                                                               │
│ ⚙️ SETTINGS                                                   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### 2. Dashboard (Main View)

**Workspace overview with pinned collections, recent uploads, and quick actions:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT                    Dashboard                          [Search] [+]  │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ 📊 WORKSPACE STATS                                                        │
│ ┌─────────────────────────────────────────────────────────────────────┐  │
│ │ 127 Artworks  │  5 Collections  │  8 Stories  │  23 Codex Entries  │  │
│ └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ 📌 PINNED COLLECTIONS                                                     │
│ ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐         │
│ │ Character        │  │ Sci-Fi World     │  │ Experimental     │         │
│ │ Studies          │  │                  │  │                  │         │
│ │ 12 pieces        │  │ 28 pieces        │  │ 5 pieces         │         │
│ │ [Last: 2 days]   │  │ [Last: 1 hour]   │  │ [Last: 1 week]   │         │
│ └──────────────────┘  └──────────────────┘  └──────────────────┘         │
│                                                                            │
│ 🆕 RECENT UPLOADS                                                         │
│ ┌────────────────────────────────────────────────────────────────────┐   │
│ │ [img] Desert Wanderer          → Character Studies    2 hours ago  │   │
│ │ [img] Neon City Skyline        → Sci-Fi World         5 hours ago  │   │
│ │ [img] Abstract Form Study       → Experimental         1 day ago   │   │
│ └────────────────────────────────────────────────────────────────────┘   │
│                                                                            │
│ 📖 ACTIVE STORIES                                                         │
│ ┌────────────────────────────────────────────────────────────────────┐   │
│ │ "The Exodus" — 15 artworks, 3 codex entries                        │   │
│ │ "Origin" — 8 artworks, 2 codex entries                             │   │
│ └────────────────────────────────────────────────────────────────────┘   │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 3. Collection View (Workspace for a Project)

**Each collection is a mini-workspace with its own timeline, codex, and story threads:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Collections > Sci-Fi World                                        │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ SCI-FI WORLD                                                              │
│ 28 artworks  │  5 codex entries  │  2 stories  │  Created 3 months ago   │
│                                                                            │
│ [📊 Stats] [📖 Codex] [⏱️ Timeline] [🗺️ Mindmap] [📚 Stories] [📤 Export] │
│                                                                            │
│ ┌─ GALLERY VIEW ──────────────────────────────────────────────────────┐  │
│ │ [img] [img] [img] [img]                                             │  │
│ │ [img] [img] [img] [img]                                             │  │
│ │ [img] [img] [img] [img]                                             │  │
│ └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ [Show Timeline] [Show Mindmap] [Show Stories]                             │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 4. Codex/Wiki Editor

**Rich text editor for documenting characters, worlds, concepts, techniques:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Codex > Characters > Aria                                         │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ ARIA — Character Profile                                                 │
│ ┌─────────────────────────────────────────────────────────────────────┐  │
│ │ [Markdown Editor]                                                   │  │
│ │                                                                     │  │
│ │ # Aria                                                              │  │
│ │ **Role:** Protagonist, Rebel Leader                                │  │
│ │ **Species:** Human-Synthetic Hybrid                                │  │
│ │ **Age:** 28                                                         │  │
│ │                                                                     │  │
│ │ ## Appearance                                                       │  │
│ │ Tall, cybernetic enhancements on left side...                      │  │
│ │                                                                     │  │
│ │ ## Character Arc                                                    │  │
│ │ [Linked to 5 artworks] [Linked to Story: "The Exodus"]             │  │
│ │                                                                     │  │
│ └─────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ LINKED ARTWORKS (5)                                                       │
│ ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐         │
│ │ [img] Portrait   │  │ [img] In Action  │  │ [img] Concept    │         │
│ └──────────────────┘  └──────────────────┘  └──────────────────┘         │
│                                                                            │
│ LINKED STORIES (1)                                                        │
│ • "The Exodus" — Aria leads the rebellion                                 │
│                                                                            │
│ [Save] [Delete] [Link Artwork] [Link Story]                              │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 5. Timeline View

**Chronological visualization of your creative evolution:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Timeline                                                          │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ YOUR CREATIVE JOURNEY                                                     │
│                                                                            │
│ 2024 Q1                                                                   │
│ ├─ Jan 15: [img] First Sketch Series (3 pieces)                          │
│ ├─ Jan 28: [img] Character Study: Aria (5 pieces)                        │
│ ├─ Feb 10: [img] Sci-Fi World Concept (8 pieces)                         │
│ │          └─ Story Started: "The Exodus"                               │
│ ├─ Feb 25: [img] Experimental Abstract (4 pieces)                        │
│ └─ Mar 12: [img] World Building: Neon Cities (6 pieces)                  │
│                                                                            │
│ 2024 Q2                                                                   │
│ ├─ Apr 03: [img] Character Refinement (3 pieces)                         │
│ ├─ Apr 20: [img] Story Illustrations: "The Exodus" (12 pieces)           │
│ │          └─ Story Completed                                           │
│ └─ May 15: [img] New Project: "Origin" Begins (2 pieces)                 │
│                                                                            │
│ [Filter by Collection] [Filter by Story] [Export Timeline]               │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 6. Mindmap/Relationship Graph

**Visual web of how your art, codex, and stories interconnect:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Mindmap                                                           │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│                          [Interactive Force Graph]                        │
│                                                                            │
│                              ◆ Aria (Character)                           │
│                             /  |  \                                       │
│                            /   |   \                                      │
│                    [Portrait] [Action] [Concept]                          │
│                      /          |          \                              │
│                     /           |           \                             │
│              ◆ Sci-Fi World ◆ The Exodus ◆ Experimental                  │
│                     \           |           /                             │
│                      \          |          /                              │
│                  [Neon City] [Story] [Abstract]                           │
│                                                                            │
│ Legend:                                                                   │
│ ◆ = Codex Entry  ■ = Artwork  ★ = Story  ◇ = Collection                 │
│                                                                            │
│ [Zoom] [Pan] [Filter by Type] [Export Graph]                             │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 7. Story Compilation Engine

**Weave artworks into narratives with text, sequencing, and metadata:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Stories > "The Exodus"                                            │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ THE EXODUS                                                                │
│ A story of rebellion and escape across a dying world                      │
│                                                                            │
│ Status: Completed  │  15 Artworks  │  3 Codex Entries  │  Created: Feb   │
│                                                                            │
│ ┌─ STORY OUTLINE ──────────────────────────────────────────────────────┐  │
│ │                                                                      │  │
│ │ ACT I: THE UPRISING                                                 │  │
│ │ └─ Scene 1: Aria discovers the truth                                │  │
│ │    └─ [img] Portrait of Aria (2 days before)                        │  │
│ │    └─ [📖] Codex: Aria's Background                                 │  │
│ │                                                                      │  │
│ │ └─ Scene 2: The rebellion forms                                     │  │
│ │    └─ [img] Underground Meeting (concept art)                       │  │
│ │    └─ [img] The Council Assembled (final render)                    │  │
│ │                                                                      │  │
│ │ ACT II: THE JOURNEY                                                 │  │
│ │ └─ Scene 3: Escape through the Neon Cities                          │  │
│ │    └─ [img] Neon Skyline (5 variations)                             │  │
│ │    └─ [📖] Codex: Neon City Architecture                            │  │
│ │                                                                      │  │
│ │ ACT III: THE EXODUS                                                 │  │
│ │ └─ Scene 4: The Final Departure                                     │  │
│ │    └─ [img] Exodus Fleet (illustration)                             │  │
│ │    └─ [img] Hope on the Horizon (final image)                       │  │
│ │                                                                      │  │
│ └──────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ [Edit Story] [Reorder Scenes] [Add Artwork] [Export Story]               │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

### 8. Export/Deployment System

**Package your work for deployment to other platforms:**

```
┌──────────────────────────────────────────────────────────────────────────┐
│ ORBIT > Exports                                                           │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│ CREATE EXPORT                                                             │
│                                                                            │
│ ┌─ Export Type ────────────────────────────────────────────────────────┐  │
│ │ ○ Web Gallery (standalone HTML/CSS)                                 │  │
│ │ ○ PDF Portfolio (print-ready)                                       │  │
│ │ ○ Social Media Collection (optimized for Instagram/Twitter)         │  │
│ │ ○ Interactive Timeline (embeddable)                                 │  │
│ │ ○ Story Book (narrative + images)                                   │  │
│ │ ○ API Export (JSON for custom integrations)                         │  │
│ └──────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ ┌─ Source ─────────────────────────────────────────────────────────────┐  │
│ │ ○ Entire Workspace                                                  │  │
│ │ ○ Specific Collection: [Sci-Fi World]                               │  │
│ │ ○ Specific Story: [The Exodus]                                      │  │
│ │ ○ Custom Selection: [Choose artworks]                               │  │
│ └──────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ ┌─ Options ────────────────────────────────────────────────────────────┐  │
│ │ ☑ Include Codex Entries                                             │  │
│ │ ☑ Include Metadata (dates, tags, descriptions)                      │  │
│ │ ☑ Include AI Analysis (style, mood, colors)                         │  │
│ │ ☐ Include Relationships (mindmap data)                              │  │
│ │ ☑ Optimize Images (for web)                                         │  │
│ │ ☑ Generate README                                                   │  │
│ └──────────────────────────────────────────────────────────────────────┘  │
│                                                                            │
│ [Preview] [Export] [Schedule Export]                                      │
│                                                                            │
│ RECENT EXPORTS                                                            │
│ • Sci-Fi World Gallery (Web) — 2 days ago — Download / View / Deploy     │
│ • The Exodus Story (PDF) — 1 week ago — Download / View                  │
│                                                                            │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## Theme Refinement

### Current Issues
- **Too gallery-like** — feels like you're displaying for others
- **Red is prominent but cold** — doesn't feel personal or creative
- **Minimal hierarchy** — hard to distinguish between types of content

### Proposed Refinements

**Color Palette (Keep Swiss foundation, add warmth):**
- Primary: Deep indigo/purple (`#2D1B69`) — creative, introspective
- Accent: Warm coral (`#FF6B4A`) — energy, creation
- Secondary: Soft sage (`#8B9E7D`) — balance, growth
- Background: Off-white (`#F8F7F3`) — warm, approachable
- Text: Deep charcoal (`#1A1A1A`) — readable, not harsh black

**Typography:**
- Keep Inter for body (clean, modern)
- Add serif accent (e.g., Merriweather) for headings — adds personality, feels more personal

**Visual Hierarchy:**
- **Codex entries** → Warm card backgrounds, serif headings
- **Artworks** → Full-bleed images with subtle overlays
- **Stories** → Timeline-style layout with narrative flow
- **Connections** → Soft, organic lines (not harsh grid)

**Micro-interactions:**
- Hover states that feel exploratory (not commercial)
- Smooth transitions between views (not snappy)
- Subtle animations for relationships (lines drawing, nodes connecting)

---

## Database Schema Additions

```sql
-- Collections (Projects/Series)
CREATE TABLE collections (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(256) NOT NULL,
  description TEXT,
  color VARCHAR(32),
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE CURRENT_TIMESTAMP
);

-- Codex Entries (Wiki/Knowledge Base)
CREATE TABLE codex_entries (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(256) NOT NULL,
  type ENUM('character', 'world', 'concept', 'technique', 'reference', 'other'),
  content LONGTEXT, -- Markdown
  collectionId INT,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE CURRENT_TIMESTAMP
);

-- Stories (Narrative Compilations)
CREATE TABLE stories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(256) NOT NULL,
  description TEXT,
  outline LONGTEXT, -- Markdown with scene structure
  status ENUM('draft', 'in_progress', 'completed', 'published'),
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW() ON UPDATE CURRENT_TIMESTAMP
);

-- Story Scenes (Ordered artworks + text)
CREATE TABLE story_scenes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  storyId INT NOT NULL,
  sceneNumber INT NOT NULL,
  title VARCHAR(256),
  description TEXT,
  artworkId INT,
  codexEntryId INT,
  createdAt TIMESTAMP DEFAULT NOW()
);

-- Artwork-to-Collection mapping
CREATE TABLE artwork_collections (
  id INT PRIMARY KEY AUTO_INCREMENT,
  artworkId INT NOT NULL,
  collectionId INT NOT NULL,
  UNIQUE(artworkId, collectionId)
);

-- Artwork-to-Story mapping
CREATE TABLE artwork_stories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  artworkId INT NOT NULL,
  storyId INT NOT NULL,
  UNIQUE(artworkId, storyId)
);

-- Codex-to-Artwork linking
CREATE TABLE codex_artworks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  codexEntryId INT NOT NULL,
  artworkId INT NOT NULL,
  UNIQUE(codexEntryId, artworkId)
);

-- Exports (Deployable packages)
CREATE TABLE exports (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(256) NOT NULL,
  type ENUM('web_gallery', 'pdf_portfolio', 'social_collection', 'timeline', 'story_book', 'api_json'),
  sourceType ENUM('workspace', 'collection', 'story', 'custom'),
  sourceId INT,
  exportData LONGTEXT, -- JSON metadata
  downloadUrl TEXT,
  createdAt TIMESTAMP DEFAULT NOW()
);
```

---

## Implementation Priority

### Phase 1 (Core Workspace)
1. Sidebar navigation redesign
2. Dashboard hub
3. Collections management
4. Basic collection views

### Phase 2 (Knowledge Base)
1. Codex/wiki editor
2. Markdown support
3. Linking system (art ↔ codex)

### Phase 3 (Narrative)
1. Story compilation engine
2. Scene sequencing
3. Story-to-art linking

### Phase 4 (Visualization)
1. Timeline view
2. Mindmap/graph visualization
3. Relationship rendering

### Phase 5 (Export)
1. Web gallery export
2. PDF portfolio export
3. Social media collections
4. API/JSON export

---

## Summary

**This transforms your app from a gallery into a personal creative operating system.** You get:

- **Workspace-first design** — organized around your projects, not viewers
- **Knowledge capture** — document your creative process, world-building, characters
- **Narrative structure** — weave artworks into stories with intent and meaning
- **Visual connections** — see how your ideas relate and evolve
- **Modular deployment** — repurpose your work for any platform
- **Warmer, personal aesthetic** — indigo/coral/sage instead of harsh red/black

This is your **visual GitHub** — a place to organize, evolve, and deploy your creative work with full control and modularity.

Ready to build this?
