import { Loader2, AlertCircle, CheckCircle2, Clock } from "lucide-react";

type Status = "pending" | "analyzing" | "complete" | "failed";

const config: Record<Status, { label: string; className: string; icon: React.ReactNode }> = {
  pending: {
    label: "Pending Analysis",
    className: "bg-muted text-muted-foreground border border-border",
    icon: <Clock className="w-3 h-3" />,
  },
  analyzing: {
    label: "Analyzing…",
    className: "bg-yellow-50 text-yellow-800 border border-yellow-200",
    icon: <Loader2 className="w-3 h-3 animate-spin" />,
  },
  complete: {
    label: "Analysis Complete",
    className: "bg-green-50 text-green-800 border border-green-200",
    icon: <CheckCircle2 className="w-3 h-3" />,
  },
  failed: {
    label: "Analysis Failed",
    className: "bg-red-50 text-red-800 border border-red-200",
    icon: <AlertCircle className="w-3 h-3" />,
  },
};

export default function AnalysisStatusBadge({ status }: { status: Status }) {
  const { label, className, icon } = config[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-1 text-[10px] font-bold tracking-wider uppercase ${className}`}
    >
      {icon}
      {label}
    </span>
  );
}
