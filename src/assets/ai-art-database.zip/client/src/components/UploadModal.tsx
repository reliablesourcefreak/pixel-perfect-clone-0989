import { useState, useCallback, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Upload, X, ImageIcon, Loader2 } from "lucide-react";

interface UploadModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface PreviewFile {
  file: File;
  preview: string;
  width?: number;
  height?: number;
}

export default function UploadModal({ open, onClose, onSuccess }: UploadModalProps) {
  const [dragging, setDragging] = useState(false);
  const [previews, setPreviews] = useState<PreviewFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadMutation = trpc.art.upload.useMutation();

  const processFiles = useCallback((files: FileList | File[]) => {
    const imageFiles = Array.from(files).filter((f) =>
      f.type.startsWith("image/")
    );
    if (imageFiles.length === 0) {
      toast.error("Please select image files only.");
      return;
    }

    const newPreviews: PreviewFile[] = [];
    let processed = 0;

    imageFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          newPreviews.push({
            file,
            preview: e.target?.result as string,
            width: img.width,
            height: img.height,
          });
          processed++;
          if (processed === imageFiles.length) {
            setPreviews((prev) => [...prev, ...newPreviews]);
          }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      processFiles(e.dataTransfer.files);
    },
    [processFiles]
  );

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) processFiles(e.target.files);
  };

  const removePreview = (index: number) => {
    setPreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (previews.length === 0) return;
    setUploading(true);
    setUploadProgress(0);

    let successCount = 0;
    for (let i = 0; i < previews.length; i++) {
      const { file, preview, width, height } = previews[i];
      try {
        // Extract base64 data (remove data:image/...;base64, prefix)
        const base64Data = preview.split(",")[1];
        await uploadMutation.mutateAsync({
          filename: file.name,
          mimeType: file.type,
          base64Data,
          fileSize: file.size,
          width,
          height,
        });
        successCount++;
        setUploadProgress(Math.round(((i + 1) / previews.length) * 100));
      } catch (err) {
        console.error("Upload failed for", file.name, err);
        toast.error(`Failed to upload ${file.name}`);
      }
    }

    setUploading(false);
    if (successCount > 0) {
      setPreviews([]);
      onSuccess();
    }
  };

  const handleClose = () => {
    if (!uploading) {
      setPreviews([]);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl rounded-none border-foreground p-0 gap-0">
        <DialogHeader className="px-6 py-4 border-b border-foreground">
          <div className="flex items-center gap-3">
            <div className="w-2 h-6 bg-primary" />
            <DialogTitle className="text-sm font-bold tracking-wider uppercase">
              Upload Artwork
            </DialogTitle>
          </div>
        </DialogHeader>

        <div className="p-6">
          {/* Drop zone */}
          {previews.length === 0 && (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed transition-colors cursor-pointer p-12 text-center ${
                dragging
                  ? "border-primary bg-primary/5"
                  : "border-foreground/30 hover:border-foreground"
              }`}
            >
              <div className="flex flex-col items-center gap-4">
                <div className={`w-12 h-12 flex items-center justify-center ${dragging ? "bg-primary" : "bg-muted"}`}>
                  <Upload className={`w-5 h-5 ${dragging ? "text-white" : "text-muted-foreground"}`} />
                </div>
                <div>
                  <p className="text-sm font-bold mb-1">
                    {dragging ? "Drop to upload" : "Drag & drop artwork here"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    or click to browse — PNG, JPG, WEBP, GIF supported
                  </p>
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleFileInput}
              />
            </div>
          )}

          {/* Previews */}
          {previews.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <p className="text-xs font-bold tracking-wider uppercase">
                  {previews.length} {previews.length === 1 ? "file" : "files"} selected
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs text-primary font-bold"
                >
                  + Add more
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handleFileInput}
                />
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-64 overflow-y-auto">
                {previews.map((p, i) => (
                  <div key={i} className="relative group aspect-square bg-muted">
                    <img
                      src={p.preview}
                      alt={p.file.name}
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => removePreview(i)}
                      className="absolute top-1 right-1 bg-foreground text-background w-5 h-5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <div className="absolute bottom-0 left-0 right-0 bg-foreground/70 px-1 py-0.5">
                      <p className="text-[9px] text-white truncate">{p.file.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload progress */}
          {uploading && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground">Uploading…</span>
                <span className="text-xs font-bold">{uploadProgress}%</span>
              </div>
              <div className="h-1 bg-muted overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground mt-2">
                AI analysis will begin automatically after upload.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-foreground flex items-center justify-between">
          <p className="text-[10px] text-muted-foreground">
            AI will auto-assign categories, tags, and find related works.
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleClose}
              disabled={uploading}
              className="rounded-none border-foreground text-xs"
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleUpload}
              disabled={previews.length === 0 || uploading}
              className="rounded-none bg-primary text-primary-foreground text-xs font-bold tracking-wider uppercase"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                  Uploading…
                </>
              ) : (
                <>
                  <Upload className="w-3 h-3 mr-2" />
                  Upload {previews.length > 0 ? `(${previews.length})` : ""}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
