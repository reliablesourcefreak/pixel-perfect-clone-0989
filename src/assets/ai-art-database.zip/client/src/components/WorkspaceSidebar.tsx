import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import {
  LayoutGrid,
  BookOpen,
  BookMarked,
  Clock,
  Plus,
  ChevronDown,
  ChevronUp,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

interface SidebarSection {
  id: string;
  label: string;
  icon: React.ReactNode;
  href: string;
}

const sections: SidebarSection[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutGrid size={20} />, href: "/dashboard" },
  { id: "collections", label: "Collections", icon: <BookMarked size={20} />, href: "/collections" },
  { id: "codex", label: "Codex", icon: <BookOpen size={20} />, href: "/codex" },
  { id: "stories", label: "Stories", icon: <BookMarked size={20} />, href: "/stories" },
];

export default function WorkspaceSidebar() {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const isActive = (href: string) => location === href || location.startsWith(href + "/");

  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-white border-r border-border transition-all duration-300 ${
        isCollapsed ? "w-20" : "w-64"
      } flex flex-col`}
    >
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        {!isCollapsed && (
          <h1 className="text-lg font-bold text-foreground">Orbit</h1>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1 hover:bg-accent rounded"
        >
          {isCollapsed ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => navigate(section.href)}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded transition-colors ${
              isActive(section.href)
                ? "bg-red-600 text-white"
                : "text-foreground hover:bg-accent"
            }`}
          >
            <span className="flex-shrink-0">{section.icon}</span>
            {!isCollapsed && <span className="text-sm font-medium">{section.label}</span>}
          </button>
        ))}
      </nav>

      {/* Quick Actions */}
      {!isCollapsed && (
        <div className="p-4 border-t border-border space-y-2">
          <Button
            onClick={() => navigate("/upload")}
            variant="default"
            className="w-full gap-2"
          >
            <Plus size={16} />
            Upload Art
          </Button>
        </div>
      )}

      {/* User Profile */}
      {!isCollapsed && (
        <div className="p-4 border-t border-border space-y-2">
          <div className="text-xs text-muted-foreground truncate">{user?.name || "User"}</div>
          <Button
            onClick={logout}
            variant="outline"
            size="sm"
            className="w-full gap-2"
          >
            <LogOut size={14} />
            Logout
          </Button>
        </div>
      )}
    </aside>
  );
}
