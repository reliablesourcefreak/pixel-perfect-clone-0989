import { useState } from "react";
import { Loader2, AlertCircle, CheckCircle2 } from "lucide-react";

interface Artwork {
  id: number;
  title: string;
  imageUrl: string;
  analysisStatus: "pending" | "analyzing" | "complete" | "failed";
  dominantColors?: string[] | null;
}

interface ArtworkCardProps {
  artwork: Artwork;
  onClick: () => void;
}

export default function ArtworkCard({ artwork, onClick }: ArtworkCardProps) {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const statusIcon = {
    pending: null,
    analyzing: <Loader2 className="w-3 h-3 animate-spin text-yellow-600" />,
    complete: <CheckCircle2 className="w-3 h-3 text-green-600" />,
    failed: <AlertCircle className="w-3 h-3 text-red-600" />,
  }[artwork.analysisStatus];

  return (
    <button
      onClick={onClick}
      className="group relative bg-background overflow-hidden aspect-square text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-primary"
    >
      {/* Image */}
      {!imgError ? (
        <img
          src={artwork.imageUrl}
          alt={artwork.title}
          className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-105 ${
            imgLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImgLoaded(true)}
          onError={() => setImgError(true)}
        />
      ) : (
        <div className="w-full h-full bg-muted flex items-center justify-center">
          <span className="text-xs text-muted-foreground">No image</span>
        </div>
      )}

      {/* Loading skeleton */}
      {!imgLoaded && !imgError && (
        <div className="absolute inset-0 bg-muted animate-pulse" />
      )}

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/60 transition-colors duration-200 flex flex-col justify-end p-3">
        <div className="translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-200">
          <p className="text-xs font-bold text-white leading-tight line-clamp-2">
            {artwork.title}
          </p>
          {/* Color swatches */}
          {artwork.dominantColors && artwork.dominantColors.length > 0 && (
            <div className="flex gap-1 mt-2">
              {artwork.dominantColors.slice(0, 3).map((color, i) => (
                <span
                  key={i}
                  className="w-3 h-3 border border-white/30"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Status indicator */}
      {statusIcon && (
        <div className="absolute top-2 right-2 bg-background/90 p-1">
          {statusIcon}
        </div>
      )}

      {/* Red corner accent for complete */}
      {artwork.analysisStatus === "complete" && (
        <div className="absolute top-0 left-0 w-0 h-0 border-t-[12px] border-l-[12px] border-t-primary border-l-primary" />
      )}
    </button>
  );
}
