import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import WorkspaceSidebar from "./components/WorkspaceSidebar";
import Gallery from "./pages/Gallery";
import ArtDetail from "./pages/ArtDetail";
import Dashboard from "./pages/Dashboard";
import Collections from "./pages/Collections";
import Codex from "./pages/Codex";
import Stories from "./pages/Stories";

function Router() {
  return (
    <div className="flex">
      <WorkspaceSidebar />
      <div className="flex-1 ml-64">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/gallery" component={Gallery} />
          <Route path="/collections" component={Collections} />
          <Route path="/codex" component={Codex} />
          <Route path="/stories" component={Stories} />
          <Route path="/art/:id" component={ArtDetail} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
