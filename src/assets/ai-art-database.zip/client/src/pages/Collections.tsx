import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus, Palette } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Collections() {
  const [, navigate] = useLocation();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState("#2D1B69");

  const collectionsQuery = trpc.collections.list.useQuery();
  const createMutation = trpc.collections.create.useMutation({
    onSuccess: () => {
      toast.success("Collection created!");
      collectionsQuery.refetch();
      setShowCreate(false);
      setName("");
      setDescription("");
    },
  });

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error("Collection name is required");
      return;
    }
    await createMutation.mutateAsync({ name, description, color });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Collections</h1>
            <p className="text-muted-foreground">Organize your art into projects and series</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)} className="gap-2">
            <Plus size={18} />
            New Collection
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Create Form */}
        {showCreate && (
          <Card className="p-6 mb-8 border-l-4 border-l-red-600">
            <h2 className="text-lg font-bold text-foreground mb-4">Create Collection</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Name</label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Character Studies"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Description</label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What's this collection about?"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Color</label>
                <div className="flex gap-2 mt-1">
                  <input
                    type="color"
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    className="w-12 h-10 rounded cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground flex items-center">{color}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  Create
                </Button>
                <Button onClick={() => setShowCreate(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Collections Grid */}
        {collectionsQuery.isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="h-32 animate-pulse bg-accent" />
            ))}
          </div>
        ) : collectionsQuery.data && collectionsQuery.data.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {collectionsQuery.data.map((collection) => (
              <Card
                key={collection.id}
                onClick={() => navigate(`/collections/${collection.slug}`)}
                className="p-6 cursor-pointer hover:shadow-lg transition-shadow border-l-4"
                style={{ borderLeftColor: collection.color || "#2D1B69" }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-foreground">{collection.name}</h3>
                    {collection.description && (
                      <p className="text-sm text-muted-foreground mt-1">{collection.description}</p>
                    )}
                  </div>
                  <Palette size={20} style={{ color: collection.color || "#2D1B69" }} />
                </div>
                <div className="text-xs text-muted-foreground">
                  Created {new Date(collection.createdAt).toLocaleDateString()}
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No collections yet</p>
            <Button onClick={() => setShowCreate(true)}>Create your first collection</Button>
          </Card>
        )}
      </div>
    </div>
  );
}
