import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus, BookMarked } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type StoryStatus = "draft" | "in_progress" | "completed" | "published";

const STATUS_COLORS: Record<StoryStatus, string> = {
  draft: "bg-gray-100 text-gray-800",
  in_progress: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  published: "bg-purple-100 text-purple-800",
};

export default function Stories() {
  const [, navigate] = useLocation();
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const storiesQuery = trpc.stories.list.useQuery();
  const createMutation = trpc.stories.create.useMutation({
    onSuccess: () => {
      toast.success("Story created!");
      storiesQuery.refetch();
      setShowCreate(false);
      setTitle("");
      setDescription("");
    },
  });

  const handleCreate = async () => {
    if (!title.trim()) {
      toast.error("Story title is required");
      return;
    }
    await createMutation.mutateAsync({ title, description });
  };

  const stories = storiesQuery.data || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Stories</h1>
            <p className="text-muted-foreground">Compile your artworks into narratives</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)} className="gap-2">
            <Plus size={18} />
            New Story
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Create Form */}
        {showCreate && (
          <Card className="p-6 mb-8 border-l-4 border-l-red-600">
            <h2 className="text-lg font-bold text-foreground mb-4">Create Story</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Title</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., The Lost Kingdom"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Description</label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Brief summary of your story"
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  Create
                </Button>
                <Button onClick={() => setShowCreate(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Stories Grid */}
        {storiesQuery.isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="h-40 animate-pulse bg-accent" />
            ))}
          </div>
        ) : stories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stories.map((story) => (
              <Card
                key={story.id}
                onClick={() => navigate(`/stories/${story.slug}`)}
                className="p-6 cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-coral-600"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-foreground">{story.title}</h3>
                    {story.description && (
                      <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                        {story.description}
                      </p>
                    )}
                  </div>
                  <BookMarked size={20} className="text-coral-600 flex-shrink-0" />
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <span
                    className={`text-xs font-medium px-2 py-1 rounded ${
                      STATUS_COLORS[story.status as StoryStatus]
                    }`}
                  >
                    {story.status}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(story.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No stories yet</p>
            <Button onClick={() => setShowCreate(true)}>Create your first story</Button>
          </Card>
        )}
      </div>
    </div>
  );
}
