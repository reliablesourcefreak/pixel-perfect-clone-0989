import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Image, BookMarked, BookOpen, Clock } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const statsQuery = trpc.workspace.getStats.useQuery();
  const activityQuery = trpc.workspace.getRecentActivity.useQuery();

  const stats = statsQuery.data;
  const activity = activityQuery.data;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Workspace</h1>
          <p className="text-muted-foreground">Manage your creative projects and ideas</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats ? (
            <>
              <Card className="p-6 border-l-4 border-l-red-600">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Artworks</p>
                    <p className="text-3xl font-bold text-foreground">{stats.artworks}</p>
                  </div>
                  <Image className="text-red-600" size={32} />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-indigo-600">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Collections</p>
                    <p className="text-3xl font-bold text-foreground">{stats.collections}</p>
                  </div>
                  <BookMarked className="text-indigo-600" size={32} />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-coral-600">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Stories</p>
                    <p className="text-3xl font-bold text-foreground">{stats.stories}</p>
                  </div>
                  <BookOpen className="text-coral-600" size={32} />
                </div>
              </Card>
              <Card className="p-6 border-l-4 border-l-sage-600">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Codex</p>
                    <p className="text-3xl font-bold text-foreground">{stats.codexEntries}</p>
                  </div>
                  <Clock className="text-sage-600" size={32} />
                </div>
              </Card>
            </>
          ) : (
            <>
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-24" />
              ))}
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="bg-white border border-border rounded p-6">
          <h2 className="text-xl font-bold text-foreground mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              onClick={() => navigate("/upload")}
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
            >
              <Plus size={24} />
              <span className="text-sm">Upload Art</span>
            </Button>
            <Button
              onClick={() => navigate("/collections")}
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
            >
              <BookMarked size={24} />
              <span className="text-sm">New Collection</span>
            </Button>
            <Button
              onClick={() => navigate("/codex")}
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
            >
              <BookOpen size={24} />
              <span className="text-sm">New Codex</span>
            </Button>
            <Button
              onClick={() => navigate("/stories")}
              variant="outline"
              className="h-24 flex flex-col items-center justify-center gap-2"
            >
              <Clock size={24} />
              <span className="text-sm">New Story</span>
            </Button>
          </div>
        </div>

        {/* Recent Activity */}
        {activity && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Recent Artworks */}
            <div className="bg-white border border-border rounded p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Recent Uploads</h2>
              <div className="space-y-3">
                {activity.recentArtworks.length > 0 ? (
                  activity.recentArtworks.map((art) => (
                    <div
                      key={art.id}
                      onClick={() => navigate(`/art/${art.id}`)}
                      className="p-3 bg-accent rounded cursor-pointer hover:bg-accent/80 transition-colors"
                    >
                      <p className="font-medium text-foreground truncate">{art.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(art.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-sm">No uploads yet</p>
                )}
              </div>
            </div>

            {/* Active Stories */}
            <div className="bg-white border border-border rounded p-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Active Stories</h2>
              <div className="space-y-3">
                {activity.activeStories.length > 0 ? (
                  activity.activeStories.map((story) => (
                    <div
                      key={story.id}
                      onClick={() => navigate(`/stories/${story.slug}`)}
                      className="p-3 bg-accent rounded cursor-pointer hover:bg-accent/80 transition-colors"
                    >
                      <p className="font-medium text-foreground truncate">{story.title}</p>
                      <p className="text-xs text-muted-foreground capitalize">{story.status}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-sm">No active stories</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
