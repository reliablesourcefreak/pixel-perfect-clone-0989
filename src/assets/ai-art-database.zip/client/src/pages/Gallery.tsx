import { useState, useCallback, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Upload,
  Search,
  X,
  RefreshCw,
  ChevronRight,
} from "lucide-react";
import UploadModal from "@/components/UploadModal";
import ArtworkCard from "@/components/ArtworkCard";


export default function Gallery() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>();
  const [selectedTag, setSelectedTag] = useState<string | undefined>();
  const [offset, setOffset] = useState(0);
  const LIMIT = 24;

  const { data: categories } = trpc.categories.list.useQuery();
  const { data: tags } = trpc.tags.list.useQuery();
  const {
    data: artData,
    isLoading,
    refetch,
  } = trpc.art.list.useQuery({
    categorySlug: selectedCategory,
    tagSlug: selectedTag,
    search: search || undefined,
    limit: LIMIT,
    offset,
  });

  const handleSearch = () => {
    setSearch(searchInput);
    setOffset(0);
  };

  const clearFilters = () => {
    setSelectedCategory(undefined);
    setSelectedTag(undefined);
    setSearch("");
    setSearchInput("");
    setOffset(0);
  };

  const hasFilters = selectedCategory || selectedTag || search;
  const artworks = artData?.items ?? [];
  const total = artData?.total ?? 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ── Top Navigation ─────────────────────────────────────────────────── */}
      <header className="border-b border-foreground sticky top-0 z-40 bg-background">
        <div className="container flex items-center justify-between h-14">
          <div className="flex items-center gap-4">
            {/* Red accent block */}
            <div className="w-3 h-8 bg-primary flex-shrink-0" />
            <span className="text-xs font-bold tracking-[0.15em] uppercase text-foreground">
              AI Art Database
            </span>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <span className="text-xs text-muted-foreground hidden sm:block">
                  {user?.name}
                </span>
                <Button
                  size="sm"
                  onClick={() => setUploadOpen(true)}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-bold tracking-wider uppercase px-4 h-8"
                >
                  <Upload className="w-3 h-3 mr-2" />
                  Upload
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-foreground text-background hover:bg-foreground/90 text-xs font-bold tracking-wider uppercase px-4 h-8"
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* ── Hero Strip ─────────────────────────────────────────────────────── */}
      <div className="border-b border-foreground">
        <div className="container py-10 grid grid-cols-12 gap-0">
          <div className="col-span-12 md:col-span-8 border-r border-foreground pr-8">
            <p className="text-label text-muted-foreground mb-3">Collection</p>
            <h1 className="text-5xl md:text-7xl font-black tracking-[-0.04em] leading-none">
              AI<br />
              <span className="text-primary">Art</span><br />
              Archive
            </h1>
          </div>
          <div className="col-span-12 md:col-span-4 pt-6 md:pt-0 md:pl-8 flex flex-col justify-end">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Upload AI-generated artwork. The system automatically analyzes
              visual style, assigns categories, generates descriptors, and maps
              relationships between pieces.
            </p>
            <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
              <span className="font-bold text-foreground">{total}</span>
              <span>works in collection</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Red divider ────────────────────────────────────────────────────── */}
      <div className="h-[3px] bg-primary" />

      <div className="container py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* ── Left Sidebar: Filters ───────────────────────────────────────── */}
          <aside className="col-span-12 md:col-span-3">
            {/* Search */}
            <div className="mb-8">
              <p className="text-label text-muted-foreground mb-3">Search</p>
              <div className="flex gap-0">
                <Input
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="Title, description…"
                  className="border-foreground rounded-none text-xs h-9 flex-1"
                />
                <Button
                  onClick={handleSearch}
                  size="sm"
                  className="rounded-none h-9 w-9 p-0 bg-foreground text-background hover:bg-primary"
                >
                  <Search className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>

            {/* Categories */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <p className="text-label text-muted-foreground">Categories</p>
                {selectedCategory && (
                  <button
                    onClick={() => { setSelectedCategory(undefined); setOffset(0); }}
                    className="text-label text-primary"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="space-y-0 border border-foreground">
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategory(
                        selectedCategory === cat.slug ? undefined : cat.slug
                      );
                      setOffset(0);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs border-b border-foreground/20 last:border-0 flex items-center justify-between transition-colors ${
                      selectedCategory === cat.slug
                        ? "bg-foreground text-background"
                        : "hover:bg-muted"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span
                        className="w-2 h-2 flex-shrink-0"
                        style={{ backgroundColor: cat.color ?? "#000" }}
                      />
                      {cat.name}
                    </span>
                    <span className="text-[10px] opacity-60">{cat.artworkCount}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Tags */}
            {tags && tags.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-label text-muted-foreground">Tags</p>
                  {selectedTag && (
                    <button
                      onClick={() => { setSelectedTag(undefined); setOffset(0); }}
                      className="text-label text-primary"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1">
                  {tags.slice(0, 30).map((tag) => (
                    <button
                      key={tag.id}
                      onClick={() => {
                        setSelectedTag(
                          selectedTag === tag.slug ? undefined : tag.slug
                        );
                        setOffset(0);
                      }}
                      className={`text-[10px] font-medium px-2 py-1 border transition-colors ${
                        selectedTag === tag.slug
                          ? "bg-primary text-primary-foreground border-primary"
                          : "border-foreground/30 hover:border-foreground"
                      }`}
                    >
                      {tag.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {hasFilters && (
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilters}
                className="w-full rounded-none border-foreground text-xs"
              >
                <X className="w-3 h-3 mr-2" />
                Clear All Filters
              </Button>
            )}
          </aside>

          {/* ── Main Gallery ─────────────────────────────────────────────────── */}
          <main className="col-span-12 md:col-span-9">
            {/* Gallery header */}
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-foreground">
              <div>
                <p className="text-label text-muted-foreground">
                  {hasFilters ? "Filtered Results" : "All Works"}
                </p>
                <p className="text-sm font-bold mt-0.5">
                  {total} {total === 1 ? "artwork" : "artworks"}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => refetch()}
                className="text-xs rounded-none"
              >
                <RefreshCw className="w-3 h-3 mr-2" />
                Refresh
              </Button>
            </div>

            {/* Loading */}
            {isLoading && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-px bg-border">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="bg-background aspect-square animate-pulse bg-muted" />
                ))}
              </div>
            )}

            {/* Empty state */}
            {!isLoading && artworks.length === 0 && (
              <div className="border border-dashed border-foreground/30 p-16 text-center">
                <div className="w-8 h-8 bg-primary mx-auto mb-4" />
                <p className="text-sm font-bold mb-2">No artworks found</p>
                <p className="text-xs text-muted-foreground mb-6">
                  {hasFilters
                    ? "Try adjusting your filters or search terms."
                    : "Upload your first AI-generated artwork to get started."}
                </p>
                {!hasFilters && isAuthenticated && (
                  <Button
                    onClick={() => setUploadOpen(true)}
                    className="bg-primary text-primary-foreground rounded-none text-xs font-bold tracking-wider uppercase"
                  >
                    <Upload className="w-3 h-3 mr-2" />
                    Upload Artwork
                  </Button>
                )}
              </div>
            )}

            {/* Artwork grid */}
            {!isLoading && artworks.length > 0 && (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-px bg-border">
                  {artworks.map((artwork: any) => (
                    <ArtworkCard
                      key={artwork.id}
                      artwork={artwork}
                      onClick={() => navigate(`/art/${artwork.id}`)}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {total > LIMIT && (
                  <div className="flex items-center justify-between mt-8 pt-4 border-t border-foreground">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={offset === 0}
                      onClick={() => setOffset(Math.max(0, offset - LIMIT))}
                      className="rounded-none border-foreground text-xs"
                    >
                      Previous
                    </Button>
                    <span className="text-xs text-muted-foreground">
                      {offset + 1}–{Math.min(offset + LIMIT, total)} of {total}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={offset + LIMIT >= total}
                      onClick={() => setOffset(offset + LIMIT)}
                      className="rounded-none border-foreground text-xs"
                    >
                      Next
                      <ChevronRight className="w-3 h-3 ml-1" />
                    </Button>
                  </div>
                )}
              </>
            )}
          </main>
        </div>
      </div>

      {/* Upload Modal */}
      <UploadModal
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onSuccess={() => {
          setUploadOpen(false);
          refetch();
          toast.success("Artwork uploaded! AI analysis is running in the background.");
        }}
      />
    </div>
  );
}
