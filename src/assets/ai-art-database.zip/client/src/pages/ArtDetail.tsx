import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  ArrowLeft,
  RefreshCw,
  Trash2,
  Loader2,
  ExternalLink,
} from "lucide-react";
import AnalysisStatusBadge from "@/components/AnalysisStatusBadge";
import ArtworkCard from "@/components/ArtworkCard";

export default function ArtDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const id = parseInt(params.id ?? "0");
  const utils = trpc.useUtils();

  const { data: artwork, isLoading, refetch } = trpc.art.getById.useQuery({ id });
  const { data: related } = trpc.art.related.useQuery({ id, limit: 6 });

  const reanalyzeMutation = trpc.art.reanalyze.useMutation({
    onSuccess: () => {
      toast.success("Re-analysis started. Refresh in a moment.");
      refetch();
    },
    onError: () => toast.error("Failed to start re-analysis."),
  });

  const deleteMutation = trpc.art.delete.useMutation({
    onSuccess: () => {
      toast.success("Artwork deleted.");
      navigate("/");
    },
    onError: () => toast.error("Failed to delete artwork."),
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!artwork) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <p className="text-sm font-bold">Artwork not found</p>
        <Button onClick={() => navigate("/")} variant="outline" className="rounded-none border-foreground text-xs">
          <ArrowLeft className="w-3 h-3 mr-2" />
          Back to Gallery
        </Button>
      </div>
    );
  }

  const relType = (type: string) => {
    const map: Record<string, string> = {
      style_similar: "Style",
      subject_similar: "Subject",
      color_similar: "Color",
      composition_similar: "Composition",
      thematic_link: "Thematic",
      technique_similar: "Technique",
    };
    return map[type] ?? type;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ── Navigation ─────────────────────────────────────────────────────── */}
      <header className="border-b border-foreground sticky top-0 z-40 bg-background">
        <div className="container flex items-center justify-between h-14">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Gallery
          </button>
          <div className="flex items-center gap-3">
            <div className="w-2 h-6 bg-primary" />
            <span className="text-xs font-bold tracking-[0.15em] uppercase">AI Art Database</span>
          </div>
          {isAuthenticated && (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => reanalyzeMutation.mutate({ id })}
                disabled={reanalyzeMutation.isPending || artwork.analysisStatus === "analyzing"}
                className="text-xs rounded-none"
              >
                <RefreshCw className="w-3 h-3 mr-1.5" />
                Re-analyze
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (confirm("Delete this artwork permanently?")) {
                    deleteMutation.mutate({ id });
                  }
                }}
                disabled={deleteMutation.isPending}
                className="text-xs rounded-none text-destructive hover:text-destructive"
              >
                <Trash2 className="w-3 h-3 mr-1.5" />
                Delete
              </Button>
            </div>
          )}
        </div>
      </header>

      <div className="h-[3px] bg-primary" />

      <div className="container py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* ── Left: Image ─────────────────────────────────────────────────── */}
          <div className="col-span-12 lg:col-span-7">
            <div className="relative bg-muted border border-border">
              <img
                src={artwork.imageUrl}
                alt={artwork.title}
                className="w-full object-contain max-h-[70vh]"
              />
              {/* Analysis status overlay */}
              {artwork.analysisStatus !== "complete" && (
                <div className="absolute top-3 left-3">
                  <AnalysisStatusBadge status={artwork.analysisStatus} />
                </div>
              )}
            </div>

            {/* Color palette */}
            {artwork.dominantColors && artwork.dominantColors.length > 0 && (
              <div className="mt-3 flex gap-0">
                {artwork.dominantColors.map((color, i) => (
                  <div
                    key={i}
                    className="h-6 flex-1"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            )}
          </div>

          {/* ── Right: Metadata ─────────────────────────────────────────────── */}
          <div className="col-span-12 lg:col-span-5">
            {/* Title */}
            <div className="mb-6 pb-6 border-b border-foreground">
              <p className="text-label text-muted-foreground mb-2">Artwork</p>
              <h1 className="text-3xl font-black tracking-[-0.03em] leading-none mb-3">
                {artwork.title}
              </h1>
              <AnalysisStatusBadge status={artwork.analysisStatus} />
            </div>

            {/* AI Description */}
            {artwork.aiDescription && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                <p className="text-label text-muted-foreground mb-2">AI Description</p>
                <p className="text-sm leading-relaxed text-foreground/80">
                  {artwork.aiDescription}
                </p>
              </div>
            )}

            {/* Categories */}
            {artwork.categories && artwork.categories.length > 0 && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                <p className="text-label text-muted-foreground mb-3">Categories</p>
                <div className="flex flex-wrap gap-2">
                  {artwork.categories.map((cat) => (
                    <span
                      key={cat.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold border border-foreground"
                    >
                      <span
                        className="w-2 h-2"
                        style={{ backgroundColor: cat.color ?? "#000" }}
                      />
                      {cat.name}
                      <span className="text-muted-foreground font-normal">
                        {Math.round((cat.confidence ?? 1) * 100)}%
                      </span>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            {artwork.tags && artwork.tags.length > 0 && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                <p className="text-label text-muted-foreground mb-3">Tags</p>
                <div className="flex flex-wrap gap-1.5">
                  {artwork.tags.map((tag) => (
                    <span
                      key={tag.id}
                      className={`text-[10px] font-bold px-2 py-1 tracking-wider uppercase ${
                        tag.type === "style"
                          ? "bg-foreground text-background"
                          : tag.type === "color"
                          ? "bg-primary text-primary-foreground"
                          : tag.type === "mood"
                          ? "bg-muted text-foreground border border-foreground/20"
                          : "border border-foreground/30 text-foreground"
                      }`}
                    >
                      {tag.name}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Style & Mood */}
            {(artwork.styleAttributes?.length || artwork.moodAttributes?.length) && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                {artwork.styleAttributes && artwork.styleAttributes.length > 0 && (
                  <div className="mb-4">
                    <p className="text-label text-muted-foreground mb-2">Style</p>
                    <div className="flex flex-wrap gap-1">
                      {(artwork.styleAttributes as string[]).map((s, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 bg-foreground text-background font-medium">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                {artwork.moodAttributes && artwork.moodAttributes.length > 0 && (
                  <div>
                    <p className="text-label text-muted-foreground mb-2">Mood</p>
                    <div className="flex flex-wrap gap-1">
                      {(artwork.moodAttributes as string[]).map((m, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 border border-foreground/30 text-foreground">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Composition & Technical */}
            {artwork.compositionNotes && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                <p className="text-label text-muted-foreground mb-2">Composition</p>
                <p className="text-xs text-foreground/70 leading-relaxed">
                  {artwork.compositionNotes}
                </p>
              </div>
            )}

            {artwork.technicalDetails && (
              <div className="mb-6 pb-6 border-b border-foreground/20">
                <p className="text-label text-muted-foreground mb-2">Technical Details</p>
                <p className="text-xs text-foreground/70 leading-relaxed">
                  {artwork.technicalDetails}
                </p>
              </div>
            )}

            {/* Color Palette */}
            {artwork.colorPalette && (artwork.colorPalette as string[]).length > 0 && (
              <div className="mb-6">
                <p className="text-label text-muted-foreground mb-2">Color Palette</p>
                <div className="flex flex-wrap gap-1">
                  {(artwork.colorPalette as string[]).map((c, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 bg-muted text-foreground border border-border">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Metadata */}
            <div className="text-[10px] text-muted-foreground space-y-1">
              {artwork.width && artwork.height && (
                <p>Dimensions: {artwork.width} × {artwork.height}px</p>
              )}
              {artwork.fileSize && (
                <p>File size: {(artwork.fileSize / 1024).toFixed(1)} KB</p>
              )}
              <p>Added: {new Date(artwork.createdAt).toLocaleDateString()}</p>
            </div>
          </div>
        </div>

        {/* ── Related Artworks ──────────────────────────────────────────────── */}
        {related && related.length > 0 && (
          <div className="mt-16 pt-8 border-t border-foreground">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-2 h-8 bg-primary" />
              <div>
                <p className="text-label text-muted-foreground">Connections</p>
                <h2 className="text-xl font-black tracking-[-0.03em]">Related Artworks</h2>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-px bg-border">
              {related.map((rel) =>
                rel.artwork ? (
                  <div key={rel.id} className="relative">
                    <ArtworkCard
                      artwork={rel.artwork}
                      onClick={() => navigate(`/art/${rel.artwork!.id}`)}
                    />
                    {/* Relationship type badge */}
                    <div className="absolute bottom-0 left-0 right-0 bg-foreground/80 px-2 py-1 pointer-events-none">
                      <p className="text-[9px] text-white font-bold tracking-wider uppercase">
                        {relType(rel.relationshipType)}
                      </p>
                      <p className="text-[9px] text-white/60">
                        {Math.round(rel.similarityScore * 100)}% match
                      </p>
                    </div>
                  </div>
                ) : null
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
