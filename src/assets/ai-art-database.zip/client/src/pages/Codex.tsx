import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus, BookOpen } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type CodexType = "character" | "world" | "concept" | "technique" | "reference" | "other";

const CODEX_TYPES: { value: CodexType; label: string }[] = [
  { value: "character", label: "Character" },
  { value: "world", label: "World" },
  { value: "concept", label: "Concept" },
  { value: "technique", label: "Technique" },
  { value: "reference", label: "Reference" },
  { value: "other", label: "Other" },
];

export default function Codex() {
  const [, navigate] = useLocation();
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState("");
  const [type, setType] = useState<CodexType>("character");
  const [filterType, setFilterType] = useState<string | null>(null);

  const codexQuery = trpc.codex.list.useQuery();
  const createMutation = trpc.codex.create.useMutation({
    onSuccess: () => {
      toast.success("Codex entry created!");
      codexQuery.refetch();
      setShowCreate(false);
      setTitle("");
      setType("character");
    },
  });

  const handleCreate = async () => {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    await createMutation.mutateAsync({ title, type });
  };

  const entries = codexQuery.data || [];
  const filtered = filterType ? entries.filter((e) => e.type === filterType) : entries;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-white">
        <div className="max-w-7xl mx-auto px-6 py-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Codex</h1>
            <p className="text-muted-foreground">Document characters, worlds, concepts, and techniques</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)} className="gap-2">
            <Plus size={18} />
            New Entry
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Create Form */}
        {showCreate && (
          <Card className="p-6 mb-8 border-l-4 border-l-red-600">
            <h2 className="text-lg font-bold text-foreground mb-4">Create Codex Entry</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Title</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Luna Skywalker"
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground">Type</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as CodexType)}
                  className="mt-1 w-full px-3 py-2 border border-border rounded bg-background"
                >
                  {CODEX_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  Create
                </Button>
                <Button onClick={() => setShowCreate(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Filters */}
        <div className="mb-6 flex gap-2 flex-wrap">
          <Button
            onClick={() => setFilterType(null)}
            variant={filterType === null ? "default" : "outline"}
            size="sm"
          >
            All
          </Button>
          {CODEX_TYPES.map((t) => (
            <Button
              key={t.value}
              onClick={() => setFilterType(t.value)}
              variant={filterType === t.value ? "default" : "outline"}
              size="sm"
            >
              {t.label}
            </Button>
          ))}
        </div>

        {/* Entries List */}
        {codexQuery.isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="h-16 animate-pulse bg-accent" />
            ))}
          </div>
        ) : filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((entry) => (
              <Card
                key={entry.id}
                onClick={() => navigate(`/codex/${entry.slug}`)}
                className="p-4 cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-l-indigo-600"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground">{entry.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      {CODEX_TYPES.find((t) => t.value === entry.type)?.label} •{" "}
                      {new Date(entry.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <BookOpen size={20} className="text-indigo-600" />
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No codex entries yet</p>
            <Button onClick={() => setShowCreate(true)}>Create your first entry</Button>
          </Card>
        )}
      </div>
    </div>
  );
}
