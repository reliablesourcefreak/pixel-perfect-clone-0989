# Orbit MVP — Personal Creative Operating System

## Phase 1: Navigation & Dashboard
- [ ] Build WorkspaceSidebar component (persistent left nav with sections)
- [ ] Build Dashboard page with workspace stats
- [ ] Display total artworks, collections, stories, codex entries
- [ ] Show pinned collections with recent activity
- [ ] Show recent uploads with thumbnails
- [ ] Show active stories with progress
- [ ] Add quick-action buttons (New Collection, New Codex, New Story, Upload)
- [ ] Update App.tsx with sidebar layout

## Phase 2: Collections System
- [ ] Build Collections list page
- [ ] Build Create Collection modal/form
- [ ] Build Collection detail page with filtered gallery
- [ ] Add collection statistics (piece count, date range)
- [ ] Implement collection pinning to dashboard
- [ ] Add edit/delete collection functionality
- [ ] Link artworks to collections (UI)

## Phase 3: Codex/Wiki System
- [ ] Build Codex list page with type filtering
- [ ] Build Codex entry editor (markdown + rich text)
- [ ] Build codex entry detail page
- [ ] Implement artwork linking (select from gallery)
- [ ] Add entry types: character, world, concept, technique, reference
- [ ] Build codex search and filtering
- [ ] Add auto-linking suggestions

## Phase 4: Story Compiler
- [ ] Build Stories list page
- [ ] Build Story editor with scene sequencing
- [ ] Build scene builder (add/reorder/edit scenes)
- [ ] Implement artwork-to-scene linking
- [ ] Implement codex-to-scene linking
- [ ] Build story detail/reader view
- [ ] Add story status tracking (draft/in_progress/completed/published)

## Phase 5: Anti-Entropy Features
- [ ] Build Quick Capture modal (fast idea logging)
- [ ] Implement auto-suggestion system (collection, tags, codex links)
- [ ] Build smart tagging (AI-powered recommendations)
- [ ] Build inbox/capture queue for unsorted uploads
- [ ] Implement auto-organization rules
- [ ] Add productivity dashboard (stats, recent activity)

## Phase 6: Quality & Testing
- [ ] Write vitest tests for all new procedures
- [ ] Test database queries
- [ ] Test navigation and routing
- [ ] Verify TypeScript compilation
- [ ] Run full test suite
- [ ] Save checkpoint

## Phase 7: Delivery
- [ ] Final review and polish
- [ ] Verify all features working end-to-end
- [ ] Deliver to user with documentation
