import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import {
  createArtwork,
  getAllCategories,
  getAllTags,
  listArtworks,
  getArtworkWithDetails,
  getRelatedArtworks,
  deleteArtwork,
  updateArtwork,
} from "./db";
import { runFullAnalysisPipeline } from "./artAnalysis";
import { collectionsRouter } from "./routers/collections";
import { codexRouter } from "./routers/codex";
import { storiesRouter } from "./routers/stories";
import { workspaceRouter } from "./routers/workspace";

// ─── Art Router ────────────────────────────────────────────────────────────────
const artRouter = router({
  // Upload artwork image (base64 encoded)
  upload: protectedProcedure
    .input(
      z.object({
        filename: z.string(),
        mimeType: z.string(),
        base64Data: z.string(),
        fileSize: z.number().optional(),
        width: z.number().optional(),
        height: z.number().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Decode base64 and upload to S3
      const buffer = Buffer.from(input.base64Data, "base64");
      const ext = input.filename.split(".").pop() ?? "jpg";
      const key = `artworks/${ctx.user.id}/${nanoid()}.${ext}`;

      const { url } = await storagePut(key, buffer, input.mimeType);

      // Create artwork record
      const artwork = await createArtwork({
        title: input.filename.replace(/\.[^.]+$/, "").replace(/[-_]/g, " "),
        imageUrl: url,
        imageKey: key,
        fileSize: input.fileSize,
        width: input.width,
        height: input.height,
        mimeType: input.mimeType,
        analysisStatus: "pending",
        uploadedBy: ctx.user.id,
      });

      if (!artwork) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create artwork" });

      // Trigger analysis asynchronously (don't await)
      runFullAnalysisPipeline(artwork.id).catch((err) =>
        console.error(`[Analysis] Background analysis failed for ${artwork.id}:`, err)
      );

      return artwork;
    }),

  // List artworks with filters
  list: publicProcedure
    .input(
      z.object({
        categorySlug: z.string().optional(),
        tagSlug: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().min(1).max(100).default(24),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      return listArtworks(input);
    }),

  // Get artwork with full details
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const artwork = await getArtworkWithDetails(input.id);
      if (!artwork) throw new TRPCError({ code: "NOT_FOUND", message: "Artwork not found" });
      return artwork;
    }),

  // Get related artworks
  related: publicProcedure
    .input(z.object({ id: z.number(), limit: z.number().default(6) }))
    .query(async ({ input }) => {
      return getRelatedArtworks(input.id, input.limit);
    }),

  // Re-run analysis on an artwork
  reanalyze: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await updateArtwork(input.id, { analysisStatus: "pending" });
      runFullAnalysisPipeline(input.id).catch((err) =>
        console.error(`[Analysis] Re-analysis failed for ${input.id}:`, err)
      );
      return { success: true };
    }),

  // Delete artwork
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await deleteArtwork(input.id);
      return { success: true };
    }),
});

// ─── Categories Router ─────────────────────────────────────────────────────────
const categoriesRouter = router({
  list: publicProcedure.query(async () => {
    return getAllCategories();
  }),
});

// ─── Tags Router ───────────────────────────────────────────────────────────────
const tagsRouter = router({
  list: publicProcedure.query(async () => {
    return getAllTags();
  }),
});

// ─── App Router ────────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  art: artRouter,
  categories: categoriesRouter,
  tags: tagsRouter,
  collections: collectionsRouter,
  codex: codexRouter,
  stories: storiesRouter,
  workspace: workspaceRouter,
});

export type AppRouter = typeof appRouter;
