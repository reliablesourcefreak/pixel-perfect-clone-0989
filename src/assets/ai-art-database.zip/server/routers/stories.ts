import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createStory,
  getAllStories,
  getStoryBySlug,
  getStoryWithScenes,
  createStoryScene,
  stories,
  storyScenes,
} from "../db";
import { getDb } from "../db";
import { eq } from "drizzle-orm";

export const storiesRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        collectionId: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const slug = input.title
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "");
      return createStory({
        title: input.title,
        slug,
        description: input.description,
        status: "draft",
        collectionId: input.collectionId,
      });
    }),

  list: protectedProcedure.query(async () => {
    return getAllStories();
  }),

  listByStatus: protectedProcedure
    .input(z.object({ status: z.string() }))
    .query(async ({ input }) => {
      const all = await getAllStories();
      return all.filter((s) => s.status === input.status);
    }),

  getBySlug: protectedProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      return getStoryBySlug(input.slug);
    }),

  getWithScenes: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getStoryWithScenes(input.id);
    }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["draft", "in_progress", "completed", "published"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.update(stories).set({ status: input.status }).where(eq(stories.id, input.id));
      return { success: true };
    }),

  addScene: protectedProcedure
    .input(
      z.object({
        storyId: z.number(),
        sceneNumber: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        artworkId: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return createStoryScene({
        storyId: input.storyId,
        sceneNumber: input.sceneNumber,
        title: input.title,
        description: input.description,
        artworkId: input.artworkId,
      });
    }),

  removeScene: protectedProcedure
    .input(z.object({ sceneId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.delete(storyScenes).where(eq(storyScenes.id, input.sceneId));
      return { success: true };
    }),
});
