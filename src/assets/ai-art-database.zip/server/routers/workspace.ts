import { protectedProcedure, router } from "../_core/trpc";
import {
  getWorkspaceStats,
  getRecentArtworks,
  getActiveStories,
  getAllCollections,
} from "../db";

export const workspaceRouter = router({
  getStats: protectedProcedure.query(async () => {
    return getWorkspaceStats();
  }),

  getRecentActivity: protectedProcedure.query(async () => {
    const [recentArtworks, activeStories, collections] = await Promise.all([
      getRecentArtworks(8),
      getActiveStories(5),
      getAllCollections(),
    ]);
    return {
      recentArtworks,
      activeStories,
      pinnedCollections: collections.filter((c) => c.isPinned),
    };
  }),
});
