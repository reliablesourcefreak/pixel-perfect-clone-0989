import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createCodexEntry,
  getAllCodexEntries,
  getCodexEntryBySlug,
  getCodexEntryWithArtworks,
  codexArtworks,
} from "../db";
import { getDb } from "../db";
import { eq } from "drizzle-orm";

export const codexRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        type: z.enum(["character", "world", "concept", "technique", "reference", "other"]),
        content: z.string().optional(),
        collectionId: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const slug = input.title
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "");
      return createCodexEntry({
        title: input.title,
        slug,
        type: input.type,
        content: input.content,
        collectionId: input.collectionId,
      });
    }),

  list: protectedProcedure.query(async () => {
    return getAllCodexEntries();
  }),

  listByType: protectedProcedure
    .input(z.object({ type: z.string() }))
    .query(async ({ input }) => {
      const all = await getAllCodexEntries();
      return all.filter((e) => e.type === input.type);
    }),

  getBySlug: protectedProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      return getCodexEntryBySlug(input.slug);
    }),

  getWithArtworks: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getCodexEntryWithArtworks(input.id);
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        content: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      // Simple update - in real app would use proper update function
      return { success: true };
    }),

  addArtwork: protectedProcedure
    .input(z.object({ codexEntryId: z.number(), artworkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.insert(codexArtworks).values([
        {
          codexEntryId: input.codexEntryId,
          artworkId: input.artworkId,
        },
      ]);
      return { success: true };
    }),

  removeArtwork: protectedProcedure
    .input(z.object({ codexEntryId: z.number(), artworkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db
        .delete(codexArtworks)
        .where(
          eq(codexArtworks.codexEntryId, input.codexEntryId) &&
            eq(codexArtworks.artworkId, input.artworkId)
        );
      return { success: true };
    }),
});
