import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createCollection,
  getAllCollections,
  getCollectionBySlug,
  getCollectionWithArtworks,
  artworkCollections,
} from "../db";
import { getDb } from "../db";
import { eq } from "drizzle-orm";

export const collectionsRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        color: z.string().optional(),
        icon: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const slug = input.name
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "");
      return createCollection({
        name: input.name,
        slug,
        description: input.description,
        color: input.color,
        icon: input.icon,
      });
    }),

  list: protectedProcedure.query(async () => {
    return getAllCollections();
  }),

  getBySlug: protectedProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      return getCollectionBySlug(input.slug);
    }),

  getWithArtworks: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getCollectionWithArtworks(input.id);
    }),

  addArtwork: protectedProcedure
    .input(z.object({ collectionId: z.number(), artworkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db.insert(artworkCollections).values([
        {
          collectionId: input.collectionId,
          artworkId: input.artworkId,
        },
      ]);
      return { success: true };
    }),

  removeArtwork: protectedProcedure
    .input(z.object({ collectionId: z.number(), artworkId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      await db
        .delete(artworkCollections)
        .where(
          eq(artworkCollections.collectionId, input.collectionId) &&
            eq(artworkCollections.artworkId, input.artworkId)
        );
      return { success: true };
    }),
});
