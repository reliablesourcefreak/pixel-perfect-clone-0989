import { eq, desc, and, inArray, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  artworks,
  categories,
  tags,
  artworkCategories,
  artworkTags,
  artworkRelationships,
  collections,
  artworkCollections,
  codexEntries,
  codexArtworks,
  stories,
  storyScenes,
  artworkStories,
  exports,
  Artwork,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

// Re-export tables for use in routers
export { artworkCollections, codexArtworks, stories, storyScenes, artworkStories };

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── User Management ──────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db
      .insert(users)
      .values(values)
      .onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Artwork Functions ────────────────────────────────────────────────────────
export async function createArtwork(data: any) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(artworks).values(data);
  const result = await db
    .select()
    .from(artworks)
    .where(eq(artworks.imageKey, data.imageKey))
    .limit(1);
  return result[0];
}

export async function updateArtwork(id: number, data: Partial<Artwork>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(artworks).set(data).where(eq(artworks.id, id));
}

export async function listArtworks(input: {
  categorySlug?: string;
  tagSlug?: string;
  search?: string;
  limit: number;
  offset: number;
}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };

  // Build query with filters
  let whereConditions: any[] = [];

  if (input.search) {
    whereConditions.push(
      sql`${artworks.title} LIKE ${"%" + input.search + "%"} OR ${artworks.description} LIKE ${"%" + input.search + "%"}`
    );
  }

  if (input.categorySlug) {
    const cat = await db
      .select({ id: categories.id })
      .from(categories)
      .where(eq(categories.slug, input.categorySlug))
      .limit(1);
    if (cat.length > 0) {
      const artIds = await db
        .select({ artworkId: artworkCategories.artworkId })
        .from(artworkCategories)
        .where(eq(artworkCategories.categoryId, cat[0].id));
      if (artIds.length === 0) return { items: [], total: 0 };
      whereConditions.push(
        sql`${artworks.id} IN (${artIds.map((a) => a.artworkId)})`
      );
    }
  }

  if (input.tagSlug) {
    const tag = await db
      .select({ id: tags.id })
      .from(tags)
      .where(eq(tags.slug, input.tagSlug))
      .limit(1);
    if (tag.length > 0) {
      const artIds = await db
        .select({ artworkId: artworkTags.artworkId })
        .from(artworkTags)
        .where(eq(artworkTags.tagId, tag[0].id));
      if (artIds.length === 0) return { items: [], total: 0 };
      whereConditions.push(
        sql`${artworks.id} IN (${artIds.map((a) => a.artworkId)})`
      );
    }
  }

  const totalResult = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(artworks)
    .where(
      whereConditions.length > 0 ? and(...whereConditions) : undefined
    );

  let query: any = db.select().from(artworks);
  if (whereConditions.length > 0) {
    query = query.where(and(...whereConditions));
  }

  const items = await query
    .orderBy(desc(artworks.createdAt))
    .limit(input.limit)
    .offset(input.offset);

  return { items, total: totalResult[0]?.count ?? 0 };
}

export async function getArtworkWithDetails(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const artwork = await db
    .select()
    .from(artworks)
    .where(eq(artworks.id, id))
    .limit(1);
  if (!artwork[0]) return undefined;

  const [artCats, artTagRows] = await Promise.all([
    db
      .select({
        categoryId: artworkCategories.categoryId,
        confidence: artworkCategories.confidence,
      })
      .from(artworkCategories)
      .where(eq(artworkCategories.artworkId, id)),
    db
      .select({
        tagId: artworkTags.tagId,
        confidence: artworkTags.confidence,
      })
      .from(artworkTags)
      .where(eq(artworkTags.artworkId, id)),
  ]);

  const catIds = artCats.map((c) => c.categoryId);
  const tagIds = artTagRows.map((t) => t.tagId);

  const [artworkCats, artworkTagsList] = await Promise.all([
    catIds.length > 0
      ? db.select().from(categories).where(inArray(categories.id, catIds))
      : Promise.resolve([]),
    tagIds.length > 0
      ? db.select().from(tags).where(inArray(tags.id, tagIds))
      : Promise.resolve([]),
  ]);

  return {
    ...artwork[0],
    categories: artworkCats.map((c) => ({
      ...c,
      confidence: artCats.find((ac) => ac.categoryId === c.id)?.confidence ?? 1,
    })),
    tags: artworkTagsList.map((t) => ({
      ...t,
      confidence: artTagRows.find((at) => at.tagId === t.id)?.confidence ?? 1,
    })),
  };
}

export async function getRelatedArtworks(artworkId: number, limit = 6) {
  const db = await getDb();
  if (!db) return [];
  const rels = await db
    .select()
    .from(artworkRelationships)
    .where(eq(artworkRelationships.artworkId, artworkId))
    .orderBy(desc(artworkRelationships.similarityScore))
    .limit(limit);
  if (rels.length === 0) return [];
  const relatedIds = rels.map((r) => r.relatedArtworkId);
  const relatedArtworks = await db
    .select()
    .from(artworks)
    .where(inArray(artworks.id, relatedIds));
  return rels.map((rel) => ({
    ...rel,
    artwork: relatedArtworks.find((a) => a.id === rel.relatedArtworkId),
  }));
}

export async function deleteArtwork(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(artworkCategories)
    .where(eq(artworkCategories.artworkId, id));
  await db.delete(artworkTags).where(eq(artworkTags.artworkId, id));
  await db
    .delete(artworkRelationships)
    .where(eq(artworkRelationships.artworkId, id));
  await db
    .delete(artworkRelationships)
    .where(eq(artworkRelationships.relatedArtworkId, id));
  await db.delete(artworks).where(eq(artworks.id, id));
}

export async function getAllCategories() {
  const db = await getDb();
  if (!db) return [];
  const cats = await db.select().from(categories);
  const counts = await Promise.all(
    cats.map(async (cat) => {
      const count = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(artworkCategories)
        .where(eq(artworkCategories.categoryId, cat.id));
      return count[0]?.count ?? 0;
    })
  );
  return cats.map((cat, i) => ({ ...cat, artworkCount: counts[i] ?? 0 }));
}

export async function getAllTags() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(tags)
    .orderBy(desc(tags.usageCount));
}

export async function assignArtworkCategories(
  artworkId: number,
  assignments: Array<{ categoryId: number; confidence: number }>
) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(artworkCategories)
    .where(
      and(
        eq(artworkCategories.artworkId, artworkId),
        eq(artworkCategories.assignedBy, "ai")
      )
    );
  if (assignments.length === 0) return;
  await db.insert(artworkCategories).values(
    assignments.map((a) => ({
      artworkId,
      categoryId: a.categoryId,
      confidence: a.confidence,
      assignedBy: "ai" as const,
    }))
  );
}

export async function assignArtworkTags(
  artworkId: number,
  tagAssignments: Array<{ tagId: number; confidence: number }>
) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(artworkTags)
    .where(
      and(eq(artworkTags.artworkId, artworkId), eq(artworkTags.assignedBy, "ai"))
    );
  if (tagAssignments.length === 0) return;
  await db.insert(artworkTags).values(
    tagAssignments.map((t) => ({
      artworkId,
      tagId: t.tagId,
      confidence: t.confidence,
      assignedBy: "ai" as const,
    }))
  );
  for (const t of tagAssignments) {
    await db
      .update(tags)
      .set({ usageCount: sql`usageCount + 1` })
      .where(eq(tags.id, t.tagId));
  }
}

export async function saveRelationships(
  artworkId: number,
  relationships: Array<{
    relatedArtworkId: number;
    relationshipType:
      | "style_similar"
      | "subject_similar"
      | "color_similar"
      | "composition_similar"
      | "thematic_link"
      | "technique_similar";
    similarityScore: number;
    notes?: string;
  }>
) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(artworkRelationships)
    .where(eq(artworkRelationships.artworkId, artworkId));
  if (relationships.length === 0) return;
  await db.insert(artworkRelationships).values(
    relationships.map((r) => ({
      artworkId,
      relatedArtworkId: r.relatedArtworkId,
      relationshipType: r.relationshipType,
      similarityScore: r.similarityScore,
      notes: r.notes,
    }))
  );
}

export async function getAllArtworksForSimilarity() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select({
      id: artworks.id,
      embedding: artworks.embedding,
      styleAttributes: artworks.styleAttributes,
      moodAttributes: artworks.moodAttributes,
      colorPalette: artworks.colorPalette,
    })
    .from(artworks)
    .where(eq(artworks.analysisStatus, "complete"));
}

export async function getArtworkById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(artworks)
    .where(eq(artworks.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrCreateTag(name: string, type: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const slug = name.toLowerCase().replace(/\s+/g, "-");
  const existing = await db
    .select()
    .from(tags)
    .where(eq(tags.slug, slug))
    .limit(1);
  if (existing.length > 0) return existing[0];
  await db.insert(tags).values([{ name, slug, type: type as any }]);
  const result = await db
    .select()
    .from(tags)
    .where(eq(tags.slug, slug))
    .limit(1);
  return result[0];
}

// ─── Collections ──────────────────────────────────────────────────────────────
export async function createCollection(data: {
  name: string;
  slug: string;
  description?: string;
  color?: string;
  icon?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(collections).values(data);
  return result;
}

export async function getAllCollections() {
  const db = await getDb();
  if (!db) return [];
  const result = await db
    .select()
    .from(collections)
    .orderBy(desc(collections.isPinned), desc(collections.createdAt));
  return result;
}

export async function getCollectionBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(collections)
    .where(eq(collections.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getCollectionWithArtworks(collectionId: number) {
  const db = await getDb();
  if (!db) return null;
  const collection = await db
    .select()
    .from(collections)
    .where(eq(collections.id, collectionId))
    .limit(1);
  if (collection.length === 0) return null;
  const artworkIds = await db
    .select({ artworkId: artworkCollections.artworkId })
    .from(artworkCollections)
    .where(eq(artworkCollections.collectionId, collectionId));
  const artworkList = await db
    .select()
    .from(artworks)
    .where(inArray(artworks.id, artworkIds.map((a) => a.artworkId)));
  return { ...collection[0], artworks: artworkList };
}

// ─── Codex Entries ────────────────────────────────────────────────────────────
export async function createCodexEntry(data: {
  title: string;
  slug: string;
  type: "character" | "world" | "concept" | "technique" | "reference" | "other";
  content?: string;
  collectionId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(codexEntries).values([data]);
  return result;
}

export async function getAllCodexEntries() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(codexEntries)
    .orderBy(desc(codexEntries.createdAt));
}

export async function getCodexEntryBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(codexEntries)
    .where(eq(codexEntries.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getCodexEntryWithArtworks(entryId: number) {
  const db = await getDb();
  if (!db) return null;
  const entry = await db
    .select()
    .from(codexEntries)
    .where(eq(codexEntries.id, entryId))
    .limit(1);
  if (entry.length === 0) return null;
  const artworkIds = await db
    .select({ artworkId: codexArtworks.artworkId })
    .from(codexArtworks)
    .where(eq(codexArtworks.codexEntryId, entryId));
  const artworkList = await db
    .select()
    .from(artworks)
    .where(inArray(artworks.id, artworkIds.map((a) => a.artworkId)));
  return { ...entry[0], artworks: artworkList };
}

// ─── Stories ──────────────────────────────────────────────────────────────────
export async function createStory(data: {
  title: string;
  slug: string;
  description?: string;
  outline?: string;
  status?: "draft" | "in_progress" | "completed" | "published";
  collectionId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(stories).values([data]);
  return result;
}

export async function getAllStories() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(stories)
    .orderBy(desc(stories.updatedAt));
}

export async function getStoryBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(stories)
    .where(eq(stories.slug, slug))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getStoryWithScenes(storyId: number) {
  const db = await getDb();
  if (!db) return null;
  const story = await db
    .select()
    .from(stories)
    .where(eq(stories.id, storyId))
    .limit(1);
  if (story.length === 0) return null;
  const scenes = await db
    .select()
    .from(storyScenes)
    .where(eq(storyScenes.storyId, storyId))
    .orderBy(storyScenes.sceneNumber);
  return { ...story[0], scenes };
}

// ─── Story Scenes ─────────────────────────────────────────────────────────────
export async function createStoryScene(data: {
  storyId: number;
  sceneNumber: number;
  title?: string;
  description?: string;
  artworkId?: number;
  codexEntryId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(storyScenes).values(data);
  return result;
}

// ─── Exports ──────────────────────────────────────────────────────────────────
export async function createExport(data: {
  name: string;
  type: "web_gallery" | "pdf_portfolio" | "social_collection" | "timeline" | "story_book" | "api_json";
  sourceType?: "workspace" | "collection" | "story" | "custom";
  sourceId?: number;
  exportData?: Record<string, unknown>;
  downloadUrl?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(exports).values([data]);
  return result;
}

export async function getAllExports() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(exports)
    .orderBy(desc(exports.createdAt));
}

// ─── Workspace Stats ──────────────────────────────────────────────────────────
export async function getWorkspaceStats() {
  const db = await getDb();
  if (!db) return null;
  const artworkCount = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(artworks);
  const collectionCount = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(collections);
  const storyCount = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(stories);
  const codexCount = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(codexEntries);
  return {
    artworks: artworkCount[0]?.count ?? 0,
    collections: collectionCount[0]?.count ?? 0,
    stories: storyCount[0]?.count ?? 0,
    codexEntries: codexCount[0]?.count ?? 0,
  };
}

export async function getRecentArtworks(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(artworks)
    .orderBy(desc(artworks.createdAt))
    .limit(limit);
}

export async function getActiveStories(limit = 5) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(stories)
    .where(
      sql`${stories.status} IN ('draft', 'in_progress', 'completed')`
    )
    .orderBy(desc(stories.updatedAt))
    .limit(limit);
}
