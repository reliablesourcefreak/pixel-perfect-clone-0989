import { invokeLLM, type Message, type ImageContent, type TextContent } from "./_core/llm";
import {
  updateArtwork,
  getAllCategories,
  getOrCreateTag,
  assignArtworkCategories,
  assignArtworkTags,
  getAllArtworksForSimilarity,
  saveRelationships,
  getArtworkById,
} from "./db";

export interface ArtworkAnalysisResult {
  title: string;
  aiDescription: string;
  styleAttributes: string[];
  moodAttributes: string[];
  colorPalette: string[];
  dominantColors: string[];
  compositionNotes: string;
  technicalDetails: string;
  suggestedCategories: Array<{ name: string; confidence: number }>;
  suggestedTags: Array<{ name: string; type: string; confidence: number }>;
  embedding: number[];
}

const ANALYSIS_PROMPT = `Analyze this AI-generated artwork and provide a comprehensive analysis. Return a JSON object with exactly these fields:
{
  "title": "A concise evocative title for this artwork (max 8 words)",
  "aiDescription": "A rich detailed description of the artwork covering subject matter visual elements atmosphere and artistic intent (2-4 sentences)",
  "styleAttributes": ["4-8 style descriptors like photorealistic impressionist cyberpunk minimalist surrealist"],
  "moodAttributes": ["3-6 mood descriptors like ethereal melancholic vibrant mysterious serene"],
  "colorPalette": ["5-8 color names like deep crimson cerulean blue warm amber"],
  "dominantColors": ["2-3 hex color codes like #2C3E50"],
  "compositionNotes": "Brief description of composition framing perspective and spatial arrangement",
  "technicalDetails": "Notes on rendering technique AI generation style lighting texture and technical characteristics",
  "suggestedCategories": [{"name": "one of: Abstract Landscape Portrait Digital 3D Render Fantasy Sci-Fi Architecture Character Concept Art", "confidence": 0.95}],
  "suggestedTags": [{"name": "specific descriptive tag", "type": "one of: style subject color composition mood technique other", "confidence": 0.9}],
  "embedding": [32 float values between -1 and 1 representing semantic visual features]
}
Provide 1-3 categories and 8-15 tags. Make embedding values reflect actual visual and thematic content.`;

export async function analyzeArtworkImage(imageUrl: string): Promise<ArtworkAnalysisResult> {
  const imgContent: ImageContent = { type: "image_url", image_url: { url: imageUrl, detail: "high" } };
  const txtContent: TextContent = { type: "text", text: ANALYSIS_PROMPT };
  const messages: Message[] = [
    {
      role: "system",
      content: "You are an expert AI art analyst and curator. Analyze the provided AI-generated artwork image in detail and return a structured JSON analysis. Be precise, descriptive, and insightful.",
    },
    {
      role: "user",
      content: [imgContent, txtContent],
    },
  ];

  const response = await invokeLLM({
    messages,
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "artwork_analysis",
        strict: true,
        schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            aiDescription: { type: "string" },
            styleAttributes: { type: "array", items: { type: "string" } },
            moodAttributes: { type: "array", items: { type: "string" } },
            colorPalette: { type: "array", items: { type: "string" } },
            dominantColors: { type: "array", items: { type: "string" } },
            compositionNotes: { type: "string" },
            technicalDetails: { type: "string" },
            suggestedCategories: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  confidence: { type: "number" },
                },
                required: ["name", "confidence"],
                additionalProperties: false,
              },
            },
            suggestedTags: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  type: { type: "string" },
                  confidence: { type: "number" },
                },
                required: ["name", "type", "confidence"],
                additionalProperties: false,
              },
            },
            embedding: { type: "array", items: { type: "number" } },
          },
          required: [
            "title",
            "aiDescription",
            "styleAttributes",
            "moodAttributes",
            "colorPalette",
            "dominantColors",
            "compositionNotes",
            "technicalDetails",
            "suggestedCategories",
            "suggestedTags",
            "embedding",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const rawContent = response.choices[0]?.message?.content;
  if (!rawContent) throw new Error("No analysis response from AI");
  const content = typeof rawContent === "string" ? rawContent : JSON.stringify(rawContent);
  return JSON.parse(content) as ArtworkAnalysisResult;
}

// ─── Full Analysis Pipeline ────────────────────────────────────────────────────
export async function runFullAnalysisPipeline(artworkId: number): Promise<void> {
  const artwork = await getArtworkById(artworkId);
  if (!artwork) throw new Error(`Artwork ${artworkId} not found`);

  await updateArtwork(artworkId, { analysisStatus: "analyzing" });

  try {
    const analysis = await analyzeArtworkImage(artwork.imageUrl);

    await updateArtwork(artworkId, {
      title: analysis.title,
      aiDescription: analysis.aiDescription,
      styleAttributes: analysis.styleAttributes,
      moodAttributes: analysis.moodAttributes,
      colorPalette: analysis.colorPalette,
      dominantColors: analysis.dominantColors,
      compositionNotes: analysis.compositionNotes,
      technicalDetails: analysis.technicalDetails,
      embedding: analysis.embedding,
      analysisStatus: "complete",
    });

    // Auto-categorize
    const allCategories = await getAllCategories();
    const categoryAssignments: Array<{ categoryId: number; confidence: number }> = [];
    for (const suggested of analysis.suggestedCategories) {
      const match = allCategories.find(
        (c) => c.name.toLowerCase() === suggested.name.toLowerCase()
      );
      if (match && suggested.confidence >= 0.4) {
        categoryAssignments.push({ categoryId: match.id, confidence: suggested.confidence });
      }
    }
    await assignArtworkCategories(artworkId, categoryAssignments);

    // Auto-tag
    const tagAssignments: Array<{ tagId: number; confidence: number }> = [];
    for (const suggested of analysis.suggestedTags) {
      if (suggested.confidence >= 0.4) {
        const tag = await getOrCreateTag(suggested.name, suggested.type);
        if (tag) {
          tagAssignments.push({ tagId: tag.id, confidence: suggested.confidence });
        }
      }
    }
    await assignArtworkTags(artworkId, tagAssignments);

    // Compute relationships
    await computeRelationships(
      artworkId,
      analysis.embedding,
      analysis.styleAttributes,
      analysis.moodAttributes,
      analysis.colorPalette
    );
  } catch (error) {
    console.error(`[Analysis] Failed for artwork ${artworkId}:`, error);
    await updateArtwork(artworkId, { analysisStatus: "failed" });
    throw error;
  }
}

// ─── Similarity Helpers ────────────────────────────────────────────────────────
function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

function jaccardSimilarity(a: string[], b: string[]): number {
  if (a.length === 0 && b.length === 0) return 0;
  const setA = new Set(a.map((s) => s.toLowerCase()));
  const setB = new Set(b.map((s) => s.toLowerCase()));
  const aArr = Array.from(setA);
  const bArr = Array.from(setB);
  const intersection = aArr.filter((x) => setB.has(x)).length;
  const union = new Set(aArr.concat(bArr)).size;
  return union === 0 ? 0 : intersection / union;
}

export async function computeRelationships(
  artworkId: number,
  embedding: number[],
  styleAttributes: string[],
  moodAttributes: string[],
  colorPalette: string[]
): Promise<void> {
  const allArtworks = await getAllArtworksForSimilarity();
  const others = allArtworks.filter((a) => a.id !== artworkId);

  type RelType =
    | "style_similar"
    | "subject_similar"
    | "color_similar"
    | "composition_similar"
    | "thematic_link"
    | "technique_similar";

  const relationships: Array<{
    relatedArtworkId: number;
    relationshipType: RelType;
    similarityScore: number;
    notes?: string;
  }> = [];

  for (const other of others) {
    if (!other.embedding || (other.embedding as number[]).length === 0) continue;

    const otherEmbedding = other.embedding as number[];
    const otherStyle = (other.styleAttributes as string[]) ?? [];
    const otherMood = (other.moodAttributes as string[]) ?? [];
    const otherColor = (other.colorPalette as string[]) ?? [];

    const embeddingSim = cosineSimilarity(embedding, otherEmbedding);
    const styleSim = jaccardSimilarity(styleAttributes, otherStyle);
    const moodSim = jaccardSimilarity(moodAttributes, otherMood);
    const colorSim = jaccardSimilarity(colorPalette, otherColor);

    const overallSim = embeddingSim * 0.5 + styleSim * 0.25 + moodSim * 0.15 + colorSim * 0.1;

    if (overallSim < 0.2) continue;

    let relType: RelType = "thematic_link";
    if (styleSim >= 0.4) relType = "style_similar";
    else if (colorSim >= 0.4) relType = "color_similar";
    else if (moodSim >= 0.4) relType = "thematic_link";
    else if (embeddingSim >= 0.5) relType = "subject_similar";

    relationships.push({
      relatedArtworkId: other.id,
      relationshipType: relType,
      similarityScore: Math.min(overallSim, 1),
      notes: `Embedding: ${embeddingSim.toFixed(2)}, Style: ${styleSim.toFixed(2)}, Mood: ${moodSim.toFixed(2)}, Color: ${colorSim.toFixed(2)}`,
    });
  }

  relationships.sort((a, b) => b.similarityScore - a.similarityScore);
  await saveRelationships(artworkId, relationships.slice(0, 10));
}
