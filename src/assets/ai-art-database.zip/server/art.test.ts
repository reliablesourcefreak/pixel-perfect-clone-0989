import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock DB and analysis modules ─────────────────────────────────────────────
vi.mock("./db", () => ({
  createArtwork: vi.fn().mockResolvedValue({
    id: 1,
    title: "Test Artwork",
    imageUrl: "https://example.com/test.jpg",
    imageKey: "artworks/1/test.jpg",
    analysisStatus: "pending",
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  getAllCategories: vi.fn().mockResolvedValue([
    { id: 1, name: "Abstract", slug: "abstract", color: "#E63946", artworkCount: 5 },
    { id: 2, name: "Landscape", slug: "landscape", color: "#2D6A4F", artworkCount: 3 },
  ]),
  getAllTags: vi.fn().mockResolvedValue([
    { id: 1, name: "vibrant", slug: "vibrant", type: "mood", usageCount: 10 },
    { id: 2, name: "photorealistic", slug: "photorealistic", type: "style", usageCount: 8 },
  ]),
  listArtworks: vi.fn().mockResolvedValue({
    items: [
      {
        id: 1,
        title: "Test Artwork",
        imageUrl: "https://example.com/test.jpg",
        imageKey: "artworks/1/test.jpg",
        analysisStatus: "complete",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ],
    total: 1,
  }),
  getArtworkWithDetails: vi.fn().mockResolvedValue({
    id: 1,
    title: "Test Artwork",
    imageUrl: "https://example.com/test.jpg",
    imageKey: "artworks/1/test.jpg",
    analysisStatus: "complete",
    aiDescription: "A vibrant abstract composition.",
    categories: [{ id: 1, name: "Abstract", slug: "abstract", color: "#E63946", confidence: 0.92 }],
    tags: [{ id: 1, name: "vibrant", slug: "vibrant", type: "mood", usageCount: 10, confidence: 0.88 }],
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  getRelatedArtworks: vi.fn().mockResolvedValue([]),
  deleteArtwork: vi.fn().mockResolvedValue(undefined),
  updateArtwork: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://cdn.example.com/test.jpg", key: "artworks/1/test.jpg" }),
}));

vi.mock("./artAnalysis", () => ({
  runFullAnalysisPipeline: vi.fn().mockResolvedValue(undefined),
}));

// ─── Auth context helpers ──────────────────────────────────────────────────────
function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────
describe("art.upload", () => {
  it("uploads artwork and returns created record", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.upload({
      filename: "my-art.png",
      mimeType: "image/png",
      base64Data: Buffer.from("fake-image-data").toString("base64"),
      fileSize: 1024,
      width: 512,
      height: 512,
    });

    expect(result).toBeDefined();
    expect(result.id).toBe(1);
    expect(result.title).toBe("Test Artwork");
  });

  it("requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.art.upload({
        filename: "test.png",
        mimeType: "image/png",
        base64Data: "abc",
      })
    ).rejects.toThrow();
  });
});

describe("art.list", () => {
  it("returns paginated artworks", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.list({ limit: 24, offset: 0 });

    expect(result.items).toHaveLength(1);
    expect(result.total).toBe(1);
    expect(result.items[0].title).toBe("Test Artwork");
  });

  it("accepts optional filters", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.list({
      categorySlug: "abstract",
      tagSlug: "vibrant",
      search: "test",
      limit: 10,
      offset: 0,
    });

    expect(result).toBeDefined();
    expect(Array.isArray(result.items)).toBe(true);
  });
});

describe("art.getById", () => {
  it("returns artwork with categories and tags", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.getById({ id: 1 });

    expect(result.id).toBe(1);
    expect(result.categories).toHaveLength(1);
    expect(result.tags).toHaveLength(1);
    expect(result.aiDescription).toBe("A vibrant abstract composition.");
  });
});

describe("art.related", () => {
  it("returns related artworks array", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.related({ id: 1, limit: 6 });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("art.delete", () => {
  it("deletes artwork when authenticated", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.art.delete({ id: 1 });

    expect(result.success).toBe(true);
  });

  it("requires authentication for deletion", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.art.delete({ id: 1 })).rejects.toThrow();
  });
});

describe("categories.list", () => {
  it("returns all categories with counts", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.categories.list();

    expect(result).toHaveLength(2);
    expect(result[0].name).toBe("Abstract");
    expect(result[0].artworkCount).toBe(5);
  });
});

describe("tags.list", () => {
  it("returns all tags ordered by usage", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.tags.list();

    expect(result).toHaveLength(2);
    expect(result[0].name).toBe("vibrant");
  });
});
