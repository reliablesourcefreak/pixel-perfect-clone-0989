import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Orbit MVP — Collections", () => {
  it("creates a collection", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collections.create({
      name: "Character Studies",
      description: "Exploring character design",
      color: "#2D1B69",
    });

    expect(result).toBeDefined();
  });

  it("lists all collections", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.collections.list();

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Orbit MVP — Codex", () => {
  it("creates a codex entry", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.codex.create({
      title: "Luna Skywalker",
      type: "character",
      content: "A mysterious character with cosmic powers",
    });

    expect(result).toBeDefined();
  });

  it("lists all codex entries", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.codex.list();

    expect(Array.isArray(result)).toBe(true);
  });

  it("filters codex entries by type", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.codex.listByType({ type: "character" });

    expect(Array.isArray(result)).toBe(true);
    result.forEach((entry) => {
      expect(entry.type).toBe("character");
    });
  });
});

describe("Orbit MVP — Stories", () => {
  it("creates a story", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.stories.create({
      title: "The Lost Kingdom",
      description: "An epic tale of discovery",
    });

    expect(result).toBeDefined();
  });

  it("lists all stories", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.stories.list();

    expect(Array.isArray(result)).toBe(true);
  });

  it("filters stories by status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.stories.listByStatus({ status: "draft" });

    expect(Array.isArray(result)).toBe(true);
    result.forEach((story) => {
      expect(story.status).toBe("draft");
    });
  });

  it("updates story status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Create a story first
    const created = await caller.stories.create({
      title: "Test Story",
      description: "Testing status update",
    });

    // Update its status (assuming the result has an id)
    const result = await caller.stories.updateStatus({
      id: 1,
      status: "in_progress",
    });

    expect(result.success).toBe(true);
  });
});

describe("Orbit MVP — Workspace", () => {
  it("retrieves workspace stats", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.workspace.getStats();

    expect(result).toBeDefined();
    expect(typeof result.artworks).toBe("number");
    expect(typeof result.collections).toBe("number");
    expect(typeof result.stories).toBe("number");
    expect(typeof result.codexEntries).toBe("number");
  });

  it("retrieves recent activity", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.workspace.getRecentActivity();

    expect(result).toBeDefined();
    expect(Array.isArray(result.recentArtworks)).toBe(true);
    expect(Array.isArray(result.activeStories)).toBe(true);
    expect(Array.isArray(result.pinnedCollections)).toBe(true);
  });
});
