-- Collections (Projects/Series)
CREATE TABLE `collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(256) NOT NULL,
	`slug` varchar(256) NOT NULL,
	`description` text,
	`color` varchar(32) DEFAULT '#2D1B69',
	`icon` varchar(64),
	`isPinned` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `collections_id` PRIMARY KEY (`id`),
	CONSTRAINT `collections_slug_unique` UNIQUE(`slug`)
);

-- Artwork ↔ Collection (many-to-many)
CREATE TABLE `artwork_collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artworkId` int NOT NULL,
	`collectionId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `artwork_collections_id` PRIMARY KEY (`id`)
);

-- Codex Entries (Wiki/Knowledge Base)
CREATE TABLE `codex_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(256) NOT NULL,
	`slug` varchar(256) NOT NULL,
	`type` enum('character','world','concept','technique','reference','other') NOT NULL DEFAULT 'other',
	`content` text,
	`collectionId` int,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `codex_entries_id` PRIMARY KEY (`id`),
	CONSTRAINT `codex_entries_slug_unique` UNIQUE(`slug`)
);

-- Codex ↔ Artwork (many-to-many)
CREATE TABLE `codex_artworks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`codexEntryId` int NOT NULL,
	`artworkId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `codex_artworks_id` PRIMARY KEY (`id`)
);

-- Stories (Narrative Compilations)
CREATE TABLE `stories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(256) NOT NULL,
	`slug` varchar(256) NOT NULL,
	`description` text,
	`outline` text,
	`status` enum('draft','in_progress','completed','published') NOT NULL DEFAULT 'draft',
	`collectionId` int,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	`updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stories_id` PRIMARY KEY (`id`),
	CONSTRAINT `stories_slug_unique` UNIQUE(`slug`)
);

-- Story Scenes (Ordered artworks + text)
CREATE TABLE `story_scenes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storyId` int NOT NULL,
	`sceneNumber` int NOT NULL,
	`title` varchar(256),
	`description` text,
	`artworkId` int,
	`codexEntryId` int,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `story_scenes_id` PRIMARY KEY (`id`)
);

-- Artwork ↔ Story (many-to-many)
CREATE TABLE `artwork_stories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artworkId` int NOT NULL,
	`storyId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `artwork_stories_id` PRIMARY KEY (`id`)
);

-- Exports (Deployable Packages)
CREATE TABLE `exports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(256) NOT NULL,
	`type` enum('web_gallery','pdf_portfolio','social_collection','timeline','story_book','api_json') NOT NULL,
	`sourceType` enum('workspace','collection','story','custom') NOT NULL DEFAULT 'workspace',
	`sourceId` int,
	`exportData` json,
	`downloadUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT `exports_id` PRIMARY KEY (`id`)
);
