import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  float,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Categories ────────────────────────────────────────────────────────────────
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  description: text("description"),
  color: varchar("color", { length: 32 }).default("#000000"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;

// ─── Tags ──────────────────────────────────────────────────────────────────────
export const tags = mysqlTable("tags", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull().unique(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  type: mysqlEnum("type", ["style", "subject", "color", "composition", "mood", "technique", "other"])
    .default("other")
    .notNull(),
  usageCount: int("usageCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Tag = typeof tags.$inferSelect;

// ─── Artworks ──────────────────────────────────────────────────────────────────
export const artworks = mysqlTable("artworks", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  aiDescription: text("aiDescription"),
  imageUrl: text("imageUrl").notNull(),
  imageKey: varchar("imageKey", { length: 512 }).notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  width: int("width"),
  height: int("height"),
  fileSize: int("fileSize"),
  mimeType: varchar("mimeType", { length: 64 }),
  // AI analysis fields
  analysisStatus: mysqlEnum("analysisStatus", ["pending", "analyzing", "complete", "failed"])
    .default("pending")
    .notNull(),
  colorPalette: json("colorPalette").$type<string[]>(),
  dominantColors: json("dominantColors").$type<string[]>(),
  styleAttributes: json("styleAttributes").$type<string[]>(),
  compositionNotes: text("compositionNotes"),
  moodAttributes: json("moodAttributes").$type<string[]>(),
  technicalDetails: text("technicalDetails"),
  // Embedding for similarity (stored as JSON array of floats)
  embedding: json("embedding").$type<number[]>(),
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Artwork = typeof artworks.$inferSelect;
export type InsertArtwork = typeof artworks.$inferInsert;

// ─── Artwork ↔ Category (many-to-many) ────────────────────────────────────────
export const artworkCategories = mysqlTable("artwork_categories", {
  id: int("id").autoincrement().primaryKey(),
  artworkId: int("artworkId").notNull(),
  categoryId: int("categoryId").notNull(),
  confidence: float("confidence").default(1.0), // AI confidence score 0-1
  assignedBy: mysqlEnum("assignedBy", ["ai", "user"]).default("ai").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtworkCategory = typeof artworkCategories.$inferSelect;

// ─── Artwork ↔ Tag (many-to-many) ─────────────────────────────────────────────
export const artworkTags = mysqlTable("artwork_tags", {
  id: int("id").autoincrement().primaryKey(),
  artworkId: int("artworkId").notNull(),
  tagId: int("tagId").notNull(),
  confidence: float("confidence").default(1.0),
  assignedBy: mysqlEnum("assignedBy", ["ai", "user"]).default("ai").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtworkTag = typeof artworkTags.$inferSelect;

// ─── Artwork Relationships ─────────────────────────────────────────────────────
export const artworkRelationships = mysqlTable("artwork_relationships", {
  id: int("id").autoincrement().primaryKey(),
  artworkId: int("artworkId").notNull(),
  relatedArtworkId: int("relatedArtworkId").notNull(),
  relationshipType: mysqlEnum("relationshipType", [
    "style_similar",
    "subject_similar",
    "color_similar",
    "composition_similar",
    "thematic_link",
    "technique_similar",
  ]).notNull(),
  similarityScore: float("similarityScore").notNull(), // 0-1
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtworkRelationship = typeof artworkRelationships.$inferSelect;

// ─── Collections (Projects/Series) ────────────────────────────────────────────
export const collections = mysqlTable("collections", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  description: text("description"),
  color: varchar("color", { length: 32 }).default("#2D1B69"),
  icon: varchar("icon", { length: 64 }),
  isPinned: int("isPinned").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Collection = typeof collections.$inferSelect;
export type InsertCollection = typeof collections.$inferInsert;

// ─── Artwork ↔ Collection (many-to-many) ──────────────────────────────────────
export const artworkCollections = mysqlTable("artwork_collections", {
  id: int("id").autoincrement().primaryKey(),
  artworkId: int("artworkId").notNull(),
  collectionId: int("collectionId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtworkCollection = typeof artworkCollections.$inferSelect;

// ─── Codex Entries (Wiki/Knowledge Base) ──────────────────────────────────────
export const codexEntries = mysqlTable("codex_entries", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  type: mysqlEnum("type", ["character", "world", "concept", "technique", "reference", "other"])
    .default("other")
    .notNull(),
  content: text("content"), // Markdown
  collectionId: int("collectionId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CodexEntry = typeof codexEntries.$inferSelect;
export type InsertCodexEntry = typeof codexEntries.$inferInsert;

// ─── Codex ↔ Artwork (many-to-many) ───────────────────────────────────────────
export const codexArtworks = mysqlTable("codex_artworks", {
  id: int("id").autoincrement().primaryKey(),
  codexEntryId: int("codexEntryId").notNull(),
  artworkId: int("artworkId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CodexArtwork = typeof codexArtworks.$inferSelect;

// ─── Stories (Narrative Compilations) ─────────────────────────────────────────
export const stories = mysqlTable("stories", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  description: text("description"),
  outline: text("outline"), // Markdown with scene structure
  status: mysqlEnum("status", ["draft", "in_progress", "completed", "published"])
    .default("draft")
    .notNull(),
  collectionId: int("collectionId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Story = typeof stories.$inferSelect;
export type InsertStory = typeof stories.$inferInsert;

// ─── Story Scenes (Ordered artworks + text) ───────────────────────────────────
export const storyScenes = mysqlTable("story_scenes", {
  id: int("id").autoincrement().primaryKey(),
  storyId: int("storyId").notNull(),
  sceneNumber: int("sceneNumber").notNull(),
  title: varchar("title", { length: 256 }),
  description: text("description"),
  artworkId: int("artworkId"),
  codexEntryId: int("codexEntryId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StoryScene = typeof storyScenes.$inferSelect;
export type InsertStoryScene = typeof storyScenes.$inferInsert;

// ─── Artwork ↔ Story (many-to-many) ───────────────────────────────────────────
export const artworkStories = mysqlTable("artwork_stories", {
  id: int("id").autoincrement().primaryKey(),
  artworkId: int("artworkId").notNull(),
  storyId: int("storyId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ArtworkStory = typeof artworkStories.$inferSelect;

// ─── Exports (Deployable Packages) ────────────────────────────────────────────
export const exports = mysqlTable("exports", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  type: mysqlEnum("type", [
    "web_gallery",
    "pdf_portfolio",
    "social_collection",
    "timeline",
    "story_book",
    "api_json",
  ]).notNull(),
  sourceType: mysqlEnum("sourceType", ["workspace", "collection", "story", "custom"])
    .default("workspace")
    .notNull(),
  sourceId: int("sourceId"),
  exportData: json("exportData").$type<Record<string, unknown>>(),
  downloadUrl: text("downloadUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Export = typeof exports.$inferSelect;
export type InsertExport = typeof exports.$inferInsert;
