CREATE TABLE `artwork_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artworkId` int NOT NULL,
	`categoryId` int NOT NULL,
	`confidence` float DEFAULT 1,
	`assignedBy` enum('ai','user') NOT NULL DEFAULT 'ai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `artwork_categories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `artwork_relationships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artworkId` int NOT NULL,
	`relatedArtworkId` int NOT NULL,
	`relationshipType` enum('style_similar','subject_similar','color_similar','composition_similar','thematic_link','technique_similar') NOT NULL,
	`similarityScore` float NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `artwork_relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `artwork_tags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`artworkId` int NOT NULL,
	`tagId` int NOT NULL,
	`confidence` float DEFAULT 1,
	`assignedBy` enum('ai','user') NOT NULL DEFAULT 'ai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `artwork_tags_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `artworks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(256) NOT NULL,
	`description` text,
	`aiDescription` text,
	`imageUrl` text NOT NULL,
	`imageKey` varchar(512) NOT NULL,
	`thumbnailUrl` text,
	`width` int,
	`height` int,
	`fileSize` int,
	`mimeType` varchar(64),
	`analysisStatus` enum('pending','analyzing','complete','failed') NOT NULL DEFAULT 'pending',
	`colorPalette` json,
	`dominantColors` json,
	`styleAttributes` json,
	`compositionNotes` text,
	`moodAttributes` json,
	`technicalDetails` text,
	`embedding` json,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `artworks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`slug` varchar(128) NOT NULL,
	`description` text,
	`color` varchar(32) DEFAULT '#000000',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_name_unique` UNIQUE(`name`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `tags` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`slug` varchar(128) NOT NULL,
	`type` enum('style','subject','color','composition','mood','technique','other') NOT NULL DEFAULT 'other',
	`usageCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tags_id` PRIMARY KEY(`id`),
	CONSTRAINT `tags_name_unique` UNIQUE(`name`),
	CONSTRAINT `tags_slug_unique` UNIQUE(`slug`)
);
